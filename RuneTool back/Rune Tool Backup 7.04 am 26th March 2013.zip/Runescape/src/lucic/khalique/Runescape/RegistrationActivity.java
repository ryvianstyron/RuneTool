package lucic.khalique.Runescape;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class RegistrationActivity extends Activity
{
	String username = "";
	EditText memberEditText;
	SharedPreferences settings;
	SharedPreferences.Editor editor;
	LinearLayout regButtons;
	LinearLayout memberTextField;
	Button memberButton;
	Button member;
	Button free2Play;
	Dialog dialog;
	Context con;
	LinearLayout everything;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		Utility.callLoaderAndHandler(new InternetChecker());
	}
	public void initializePageView()
	{
		setContentView(R.layout.registrationview);
		everything = (LinearLayout)findViewById(R.id.everything);
		// Check to see if SharedPreferences have been set ever
		SharedPreferences existingSettings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		String settingExists = existingSettings.getString("memberType",null);
		if(settingExists!=null) // Been set, move to home activity
		{
			Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
			startActivity(intent);
		}
		everything.setVisibility(View.VISIBLE);
		free2Play = (Button)findViewById(R.id.free2play);
		member = (Button) findViewById(R.id.pay2play);
		memberButton = (Button) findViewById(R.id.memberButton);
		memberEditText = (EditText)findViewById(R.id.memberEditText);
		regButtons = (LinearLayout)findViewById(R.id.accountButtons);
		memberTextField = (LinearLayout)findViewById(R.id.memberTextField);
		
		// Create Listeners
		free2Play.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
				Bundle b = new Bundle();
				b.putString("memberType", "free2play");
				intent.putExtras(b);
				settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
				editor = settings.edit();
				editor.putString("memberType", "free2play");
				editor.putString("registered", "yes");
				editor.commit();
				startActivity(intent);
			}
		});
		member.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				regButtons.setVisibility(View.GONE);
				memberTextField.setVisibility(View.VISIBLE);
			}
		});
		memberButton.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				username = memberEditText.getText().toString();
				if(username.equals("Enter Member Name") ||username.equals(""))
				{
					Toast.makeText(RegistrationActivity.this,"Please enter a valid username ..", Toast.LENGTH_LONG).show();
				}
				else
				{
					username = memberEditText.getText().toString();
					username = username.trim();
					Utility.callLoaderAndHandler(new Validator());
				}
			}
		});
	}
	public void onBackPressed()
	{
		super.onBackPressed();
		this.finish();
	}
	private class InternetChecker extends AsyncTask<String, Void, String>
	{
		Dialog loadingDialog;
		protected void onPreExecute()
		{
			loadingDialog = Utility.createLoadingScreen("Loading ..", RegistrationActivity.this, loadingDialog);
			loadingDialog.show();
		}
		protected String doInBackground(String... params)
		{
			while(!isCancelled())
			{
					if(!isOnline())
					{
						return "nic";
					}
					return "good";
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("good"))
			{
				loadingDialog.dismiss();
				initializePageView();
			}
			if(result.equals("nic"))
			{
				loadingDialog.dismiss();
				dialog = createInternetDialog();
				dialog.show();
			}
		}
		@Override
		protected void onCancelled()
		{
			loadingDialog.dismiss();
			dialog = createInternetDialog();
			dialog.show();
		}
	}
	public Dialog createInternetDialog()
	{
		dialog = new Dialog(RegistrationActivity.this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.internetdialog);
		dialog.setCancelable(false);
		Button quit = (Button)dialog.findViewById(R.id.quit);
		quit.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				dialog.dismiss();
				finish();
			}
		});
		return dialog;
	}
	public boolean isOnline() 
	{
	    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo netInfo = cm.getActiveNetworkInfo();
	    if (netInfo != null && netInfo.isConnectedOrConnecting()) 
	    {
	        return true;
	    }
	    return false;
	}
	private class Validator extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = Utility.createLoadingScreen("Validating " + username + " ..", RegistrationActivity.this, dialog);
			dialog.show();
		}

		protected String doInBackground(String... params)
		{
			while(!isCancelled())
			{
				try 
				{
					//Handle XML
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					String username1 = username.replace(" ","+");
					URL sourceUrl = new URL("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + username1); //Send URL to Parse XML Tags
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
					return "completed";
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					return "incomplete";
				}
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				dialog.dismiss();
				Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
				Bundle b = new Bundle();
				b.putString("memberType","pay2play");
				b.putString("memberName", username);
				intent.putExtras(b);
				settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
				editor = settings.edit();
				editor.putString("memberType", "pay2play");
				editor.putString("memberName", username);
				editor.putString("registered", "yes");
				editor.commit();
				startActivity(intent);
			}
			else
			{
				dialog.dismiss();
				Toast.makeText(RegistrationActivity.this, "User Validation failed, have you entered your username correctly? Are you a member? ..", Toast.LENGTH_LONG).show();
			}
		}
		@Override
		protected void onCancelled()
		{
			dialog.dismiss();
			Toast.makeText(RegistrationActivity.this, "Validation from www.runescape.com is slow, please try again later ..", Toast.LENGTH_LONG).show();
		}
	}
}