package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.json.JSONObject;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Utility
{
	public static Dialog createLoadingScreen(String message, Context con, Dialog dialog)
	{
		dialog = new Dialog(con);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.miniloading);
		ImageView image = (ImageView)dialog.findViewById(R.id.loadinglogo);
		TextView text = (TextView)dialog.findViewById(R.id.loadingtext);
		image.setImageBitmap(null);
		image.setBackgroundResource(R.drawable.loadingscreenanimation);
		final AnimationDrawable splashAnimation = (AnimationDrawable) image.getBackground();
		image.post(new Runnable()
		{
			public void run() 
			{
				if ( splashAnimation != null ) splashAnimation.start();
			}
		});
		dialog.setCancelable(false);
		text.setText(message);
		return dialog;
	}
	public static String convertStreamToString(InputStream in)throws UnsupportedEncodingException
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,"UTF-8"));
		StringBuilder sb = new StringBuilder();
		String line = null;
		try
		{
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
		} 
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				in.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return sb.toString();
	}
	public static Dialog createSimpleDialog(String message, Context con, Dialog dialog)
	{
		dialog = new Dialog(con);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.miniloading);
		ImageView image = (ImageView)dialog.findViewById(R.id.loadinglogo);
		image.setVisibility(View.GONE);
		TextView text = (TextView)dialog.findViewById(R.id.loadingtext);
		text.setText(message);
		dialog.setCancelable(true);
		return dialog;
	}
	public static void callLoaderAndHandler(final AsyncTask<String, Void, String> loaderClass)
	{
		loaderClass.execute();
		Handler handler = new Handler();
		handler.postDelayed(new Runnable()
		{
			public void run()
			{
				if(loaderClass.getStatus() == AsyncTask.Status.RUNNING)
				{
					loaderClass.cancel(true);
				}
			}
		}, 30000);
	}
	public static double largest(double a, double b, double c)
	{
		double largest = 0;
		if(a > b && a > c)
		{
			largest = a;
		}
		else if(b > a && b > c)
		{
			largest = b;
		}
		else if(c > a && c > b)
		{
			largest = c;
		}
		return largest;
	}
}
