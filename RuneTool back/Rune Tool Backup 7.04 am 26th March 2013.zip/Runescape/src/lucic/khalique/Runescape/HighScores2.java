package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class HighScores2 extends ListActivity
{
	static HashMap<String, Integer> images = new HashMap<String, Integer>();
	ArrayList<HashMap<String, Object>> list;
	HttpClient client = new DefaultHttpClient();
	HttpGet httpGet;
	String url;
	String[] highScores;
	String[][] skills;
	String[] skillItem;
	final int RANK = 0;
	final int LEVEL = 1;
	final int TOTALXP = 2;
	final int SKILLNAME = 4;
	String[] skillNames = { "Overall", "Attack", "Defense", "Strength",
			"Constitution", "Ranged", "Prayer", "Magic", "Cooking",
			"Woodcutting", "Fletching", "Fishing", "Firemaking", "Crafting",
			"Smithing", "Mining", "Herblore", "Agility", "Thieving", "Slayer",
			"Farming", "Runecrafting", "Hunter", "Construction", "Summoning",
			"Dungeoneering" };
	Dialog dialog;
	String username = "";
	SimpleAdapter adapter;
	LinearLayout highscorestitle;
	SharedPreferences settings;
	SharedPreferences.Editor editor;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.hslistview);

		initAlogMap();
		list = new ArrayList<HashMap<String, Object>>();
		adapter = new SimpleAdapter(this, list,
				R.layout.hslistitem, new String[] { "image", "skill", "level",
						"xp" }, new int[] { R.id.hsimage, R.id.skillname,
						R.id.hslevel, R.id.hsxp });

		username = getIntent().getExtras().getString("username");
		highscorestitle = (LinearLayout)findViewById(R.id.highscorestitle);
		highscorestitle.setVisibility(View.GONE);
		Utility.callLoaderAndHandler(new HiScoresLoader());
	}
	public void onResume()
	{
		super.onResume();
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		String registered = settings.getString("registered","null");
		if(registered != null && registered.equals("no"))
		{
			finish();
		}
	}
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		this.finish();
	}
	public boolean onCreateOptionsMenu(Menu menu)
    {
    	MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.runescape_menu, menu);
        return true;
    }
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Create settings and editor
		settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		editor = settings.edit();
		// handle item selection
	     switch (item.getItemId()) 
	     {
	         case R.id.logout:
	        	 editor.clear();
	        	 editor.putString("registered","no");
	        	 editor.commit();
	        	 Intent intent = new Intent(HighScores2.this, RegistrationActivity.class);
	        	 startActivity(intent);
	        	 finish();
	             return true;
	         default:return super.onOptionsItemSelected(item);
	     }
	}
	private class HiScoresLoader extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = Utility.createLoadingScreen("Loading " + username + " HighScores ..", HighScores2.this, dialog);
			dialog.show();
		}
		@Override
		protected String doInBackground(String... arg0)
		{
			while(!isCancelled())
			{
				username = username.replace(" ", "+");
				url = "http://hiscore.runescape.com/index_lite.ws?player=" + username;
				httpGet = new HttpGet(url);
				String result = ""; // Where the resulting webpage will be stored
				try
				{
					HttpResponse response = client.execute(httpGet);
					BufferedReader in = new BufferedReader(new InputStreamReader(
							response.getEntity().getContent()));
					StringBuffer sb = new StringBuffer("");
					String line = "";
					String NL = System.getProperty("line.separator");
					while ((line = in.readLine()) != null)
					{
						sb.append(line + NL);
					}
					in.close();
					result = sb.toString(); // Resulting content of the page
					parseHighScores(result);
					return "completed";
				} 
				catch (ClientProtocolException e)
				{
					System.out.print("ERROR: ClientProtocolException " + e.toString());
					return "incomplete";
				} 
				catch (Exception e)
				{
					System.out.print("ERROR: Exception " + e.toString());
					return "incomplete";
				}
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			System.out.println(result);
			if(result.equals("completed") && dialog.isShowing())
			{
				highscorestitle.setVisibility(View.VISIBLE);
				populateList();
				setListAdapter(adapter);
				dialog.dismiss();
			}
			if(result.equals("incomplete") && dialog.isShowing())
			{
				Toast.makeText(HighScores2.this, "HighScores is unavailable at this time, please try again later ..", Toast.LENGTH_LONG).show();
				dialog.dismiss();
			}
		}
		@Override
		protected void onCancelled()
		{
			dialog.dismiss();
			Toast.makeText(HighScores2.this, "HighScores response from www.runescape.com is slow, please try again later ..", Toast.LENGTH_LONG).show();
		}
	}
	public void populateList()
	{
		HashMap<String, Object> temp = new HashMap<String, Object>();
		for (int i = 0; i < skills.length; i++)
		{
			temp = new HashMap<String, Object>();
			temp.put("image", images.get(skillNames[i]));
			temp.put("skill", skillNames[i]);
			temp.put("level", "" + skills[i][LEVEL]);
			temp.put("xp", skills[i][TOTALXP]);
			list.add(temp);
		}
	}
	public void onListItemClick(ListView l, View v, int position, long id)
	{
		super.onListItemClick(l, v, position, id);
		final Dialog dialog = new Dialog(HighScores2.this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.showleveldesc);
		dialog.setCancelable(true);

		Button image = (Button) dialog.findViewById(R.id.levelimage);
		TextView title = (TextView) dialog.findViewById(R.id.leveltitle);
		TextView level = (TextView) dialog.findViewById(R.id.level);
		TextView rank = (TextView) dialog.findViewById(R.id.rank);
		TextView xp = (TextView) dialog.findViewById(R.id.totalxp);
		TextView nextxp = (TextView) dialog.findViewById(R.id.nextxp);
		ProgressBar bar = (ProgressBar) dialog.findViewById(R.id.progress);
		Button dismiss = (Button) dialog.findViewById(R.id.dismiss);
		TextView percentText = (TextView)dialog.findViewById(R.id.percent);

		String skill = skillNames[position];
		int levelNo = Integer.parseInt(skills[position][LEVEL]);
		int xpNo = Integer.parseInt(skills[position][TOTALXP]);
		int rankNo = Integer.parseInt(skills[position][RANK]);

		dismiss.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
			}
		});
		image.setBackgroundResource(images.get(skillNames[position]));
		title.setText(skill);
		level.setText("Level : " + levelNo);
		rank.setText("Rank : " + rankNo);
		xp.setText("Experience : " + xpNo);

		double nextLevel = 0;
		for (int i = 1; i < levelNo + 1; i++) // maybe its not levelNo + 1?
		{
			double o = i / 7.0;
			double p = Math.pow(2, o);
			double q = 300 * p;

			nextLevel += Math.floor(i + q);
		}
		nextLevel = Math.floor(nextLevel / 4);

		double missingXp = nextLevel - xpNo;

		double minXpForCurrentLevel = 0;
		for (int i = 1; i < levelNo; i++) // maybe its not levelNo + 1?
		{
			double o = i / 7.0;
			double p = Math.pow(2, o);
			double q = 300 * p;

			minXpForCurrentLevel += Math.floor(i + q);
		}
		minXpForCurrentLevel = Math.floor(minXpForCurrentLevel / 4);

		double progressThroughLevel = xpNo - minXpForCurrentLevel;
		double totalXpForLevel = nextLevel - minXpForCurrentLevel;
		double remainingXp = nextLevel - xpNo;
		double percentProgress = (progressThroughLevel * 100) / totalXpForLevel;

		double meleeLevel = calculateMelee();
		double magicLevel = calculateMagic();
		double rangedLevel = calculateRanged();
		
		double combatLevel = Utility.largest(meleeLevel, magicLevel, rangedLevel);

		if(skill.contains("Overall"))
		{
			nextxp.setText("Combat Level is: " + (int)combatLevel + "\n" +  "\n" + "Progress to Level 138 is:");
			double percent = combatLevel/138;
			percent = percent*100;
			bar.setProgress((int)percent);
			percentText.setText("" + (int)percent + "%");
		}
		if (xpNo == 0 || percentProgress == 0)
		{
			bar.setProgress(0);
			nextxp.setText("Xp to Level " + (levelNo + 1) + " : " + (int)remainingXp);
			percentText.setText("0%");
		} else
		{
			if(levelNo==99 && !(skill.contains("Dungeoneering")))
			{
				
				nextxp.setVisibility(View.GONE);
				bar.setProgress(100);
				percentText.setText("100%");
			}
			if(levelNo == 120 && skill.contains("Dungeoneering"))
			{
				nextxp.setVisibility(View.GONE);
				bar.setProgress(100);
				percentText.setText("100%");
			}
			if(levelNo != 99 && !(skill.contains("Overall")))
			{
				Log.i("OOOOOOO", "");
				Log.i("percent Through Level: ", "" + percentProgress);
				Log.i("DEBUG", "xp for " + levelNo + " is " + minXpForCurrentLevel);
				Log.i("DEBUG", "xp for " + (levelNo + 1) + " is " + nextLevel);
				Log.i("DEBUG", "xp left for " + (levelNo + 1) + " "
					+ skillNames[position] + " is " + remainingXp);
				Log.i("next Level: ", "" + missingXp);
				bar.setProgress((int) percentProgress);
				percentText.setText((int)percentProgress + "%");
				nextxp.setText("Xp to Level " + (levelNo + 1) + " : " + (int)remainingXp);
			}	
		}
		dialog.show();
	}
	public void parseHighScores(String scores)
	{
		// highScores = scores.split(" ");
		StringTokenizer st = new StringTokenizer(scores);
		int count = st.countTokens();
		highScores = new String[count];
		count = 0;
		while (st.hasMoreElements())
		{
			highScores[count] = "" + st.nextElement();
			count++;
		}
		skills = new String[26][3];
		for (int i = 0; i < 26; i++)
		{
			st = new StringTokenizer(highScores[i], ",");
			int count2 = 0;
			while (st.hasMoreElements())
			{
				skills[i][count2] = "" + st.nextElement();
				if (skills[i][count2].contains("-1"))
				{
					skills[i][count2] = "0";
				}
				count2++;
			}
		}
	}
	public void initAlogMap()
	{
		images.put("Overall", R.drawable.overall);
		images.put("Fletching", R.drawable.fletching);
		images.put("Agility", R.drawable.agility);
		images.put("Attack", R.drawable.attack);
		images.put("Construction", R.drawable.construction);
		images.put("Cooking", R.drawable.cooking);
		images.put("Crafting", R.drawable.crafting);
		images.put("Defense", R.drawable.defense);
		images.put("Dungeoneering", R.drawable.dungeon);
		images.put("Farming", R.drawable.farming);
		images.put("Firemaking", R.drawable.firemaking);
		images.put("Fishing", R.drawable.fishing);
		images.put("Herblore", R.drawable.herblore);
		images.put("Constitution", R.drawable.hitpoint);
		images.put("Hunter", R.drawable.hunter);
		images.put("Magic", R.drawable.magic);
		images.put("Mining", R.drawable.mining);
		images.put("Ranged", R.drawable.ranged);
		images.put("Slayer", R.drawable.slayer);
		images.put("Strength", R.drawable.strength);
		images.put("Summoning", R.drawable.summoning);
		images.put("Thieving", R.drawable.thieving);
		images.put("Woodcutting", R.drawable.woodcutting);
		images.put("Runecrafting", R.drawable.runecrafting);
		images.put("Prayer", R.drawable.prayer);
		images.put("Smithing", R.drawable.smithing);
	}
	public double calculateRanged()
	{
		double ranged = Integer.parseInt(skills[5][LEVEL]);
		double defense = Integer.parseInt(skills[2][LEVEL]);
		double hp = Integer.parseInt(skills[4][LEVEL]);
		double prayer = Integer.parseInt(skills[6][LEVEL]);
		double summon = Integer.parseInt(skills[24][LEVEL]);
		prayer = 0.5*prayer;
		summon = 0.5*summon;
		ranged = 1.3*1.5*ranged;
		double level = 0.25*(ranged + defense + hp +prayer + summon);
		return level;
	}
	public double calculateMelee()
	{
		double attack = Integer.parseInt(skills[1][LEVEL]);
		double strength = Integer.parseInt(skills[3][LEVEL]);
		double defense = Integer.parseInt(skills[2][LEVEL]);
		double hp = Integer.parseInt(skills[4][LEVEL]);
		double prayer = Integer.parseInt(skills[6][LEVEL]);
		double summon = Integer.parseInt(skills[24][LEVEL]);
		double mele = 1.3*(attack+strength);
		prayer = 0.5*prayer;
		summon = 0.5*summon;
		double level = 0.25*(mele+defense+hp+prayer+summon);
		return level;
	}
	public double calculateMagic()
	{
		double magic = Integer.parseInt(skills[7][LEVEL]);
		double defense = Integer.parseInt(skills[2][LEVEL]);
		double hp = Integer.parseInt(skills[4][LEVEL]);
		double prayer = Integer.parseInt(skills[6][LEVEL]);
		double summon = Integer.parseInt(skills[24][LEVEL]);
		prayer = 0.5*prayer;
		summon = 0.5*summon;
		magic = 1.3*1.5*magic;
		double level = 0.25*(magic+defense+hp+prayer+summon);
		return level;
	}
}
