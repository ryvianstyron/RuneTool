package lucic.khalique.Runescape;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class MyNewsHandler extends DefaultHandler
{
    private Boolean inTitle = false;
    private Boolean inDescription = false;
    private Boolean inItem = false;
    private Boolean inCategory = false;
    static public ArrayList<String> title = new ArrayList<String>(),
	    description = new ArrayList<String>(), category = new ArrayList<String>();
    private StringBuilder buff = null;
    // All methods auto called in this order - start, characters, end
    /*
     * Called when an xml tag starts
     * imgView.setImageResource(R.drawable.newImage);
     */
    @Override
    public void startElement(String uri, String localName, String qName,Attributes attributes) 
    {
    	if (inItem) 
    	{
    		if (localName.equals("title")) 
    		{
    			inTitle = true;
    			buff = new StringBuilder();
    		}
    		if (localName.equals("description")) 
    		{
    			inDescription = true;
    			buff = new StringBuilder();
    		}
    		if (localName.equals("category")) 
    		{
    			inCategory = true;
    			buff = new StringBuilder();
    		}
    		
    	}
    	if (localName.equals("item")) 
    	{
    		inItem = true;
    	}
    }
    /*
     * Called when an xml tag ends
     */
    @Override
    public void endElement(String uri, String localName, String qName)throws SAXException 
    {
    	if (!inTitle && !inDescription && !inCategory) 
    	{
    		inItem = false;
    	} 
    	else 
    	{
    		if (inTitle) 
    		{
    			String check = buff.toString().trim();
    			title.add(check);
    			inTitle = false;
    			buff = null;
    		}
    		if (inDescription) 
    		{
    			String check2 = buff.toString().trim();
    			String array [];
    			int index = 0;
    			if (check2.contains("/>"))
				{
					array = check2.split("/>");
					index = check2.indexOf("10;");
					description.add(array[array.length - 1].trim());
				}

    			else description.add(check2);
    			//description.add(array[1]);
    			inDescription = false;
    			buff = null;
    		}
    		if(inCategory)
    		{
    			String check = buff.toString().trim();
    			category.add(check);
    			inCategory = false;
    			buff = null;
    		}
    	}
    }
    /*
     * Called to get tag characters
     */
    @Override
    public void characters(char ch[], int start, int length) 
    {
    	if (buff != null) 
    	{
    		for (int i = start; i < start + length; i++) 
    		{
    			buff.append(ch[i]);
    		}
    	}
    }
}
