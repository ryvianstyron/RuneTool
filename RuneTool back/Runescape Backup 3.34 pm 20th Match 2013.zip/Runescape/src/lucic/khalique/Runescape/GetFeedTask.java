package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.os.AsyncTask;
import android.util.Log;

public class GetFeedTask extends AsyncTask<Void, Void, Boolean>
{

	String url = "http://services.runescape.com/m=news/latest_news.rss";
	String loadResult;

	@Override
	public Boolean doInBackground(Void... params)
	{
		return getFeed();
	}

	private boolean getFeed()
	{
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet httpget = new HttpGet(url);
		try
		{
			// Execute HTTP get Request
			HttpResponse response = httpclient.execute(httpget);

			// Extract the page content returned from the response
			BufferedReader in = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			StringBuffer sb = new StringBuffer("");
			String line = "";
			String NL = System.getProperty("line.separator");
			while ((line = in.readLine()) != null)
			{
				sb.append(line + NL);
			}
			in.close();
			loadResult = sb.toString(); // resulting content of the page
		} 
		catch (ClientProtocolException e)
		{
			Log.d("ERROR", "ClientProtocolException=" + e);
			System.err.println("ClientProtocolException=" + e);
			return false;
		} 
		catch (IOException e)
		{
			Log.d("ERROR", "IOException=" + e);
			System.err.println("IOException=" + e);
			return false;
		}

		return true;// return true if successful, false if not
	}

	@Override
	public void onPostExecute(Boolean result) // Called Automatically
	{
		//Intent intent = new Intent(HomeActivity.class, News.class);
	}
}