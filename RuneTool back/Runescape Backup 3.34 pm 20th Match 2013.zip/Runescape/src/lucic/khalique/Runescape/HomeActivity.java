package lucic.khalique.Runescape;

import java.net.URL;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends Activity
{
	String username = "";
	Button alog;
	Button news;
	Button forumTime;
	Button hiScores;
	Button ge;
	Button friends;
	EditText usernameEntry;
	SharedPreferences preferences;
	ImageView image;
	TextView usernametv;
	Dialog dialog;
	
	private XMLList newsList;
	private XMLList alogList;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		
		//String memberType = getIntent().getExtras().getString("memberType");
		
		friends = (Button)findViewById(R.id.friendButton);
		forumTime = (Button)findViewById(R.id.timeButton);
		news = (Button) findViewById(R.id.newsButton);
		alog = (Button) findViewById(R.id.alogButton);
		hiScores = (Button)findViewById(R.id.hiScoresButton);
		ge = (Button)findViewById(R.id.geButton);
		
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		
		String memberType = settings.getString("memberType",null);
		String memberName = settings.getString("memberName",null);		
	
		if(memberType.equals("free2play"))
		{
			alog.setVisibility(View.GONE);
			hiScores.setVisibility(View.GONE);
		}
		else if(memberType.equals("pay2play"))
		{
			username = memberName;
		}
		
		OnClickListener friendsListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, FriendsActivity.class);
				startActivity(intent);
			}
		};
		OnClickListener hiScoresListener = new OnClickListener()
		{
			public void onClick(View v)
			{
					Intent intent = new Intent(HomeActivity.this, HighScores2.class);
					Bundle b = new Bundle();
					b.putString("username",username);
					intent.putExtras(b);
					startActivity(intent);
			}
		};
		OnClickListener geListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, GeHome.class);
				startActivity(intent);
			}
		};
		OnClickListener alogListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				AlogLoader loader = new AlogLoader();
				loader.execute();
			}
		};
		//For news button
		OnClickListener newsListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				NewsLoader loader = new NewsLoader();
				loader.execute();
			}
		};
		//For Forum time
		OnClickListener timeListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, Time.class);
				startActivity(intent);
			}
		};
		
		//Attaching listeners
		friends.setOnClickListener(friendsListener);
		forumTime.setOnClickListener(timeListener);
		alog.setOnClickListener(alogListener);
		news.setOnClickListener(newsListener);
		hiScores.setOnClickListener(hiScoresListener);
		ge.setOnClickListener(geListener);
	}

	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 300000).show();
	}
	
	 public boolean onCreateOptionsMenu(Menu menu)
	    {
	    	MenuInflater inflater = getMenuInflater();
	        inflater.inflate(R.menu.runescape_menu, menu);
	        
	        MenuItem modules = (MenuItem)menu.findItem(R.id.logout);
	        
	        //MenuItem settings = (MenuItem)menu.findItem(R.id.settings_menu_it;
	        //modules.setIntent(new Intent(this, ModuleList.class));
	        //settings.setIntent(new Intent(this, Settings.class).);
	        
	        return true;
	    }
	 public boolean onOptionsItemSelected(MenuItem item) 
	 {
	     // Handle item selection
	     switch (item.getItemId()) 
	     {
	         case R.id.logout:
	        	 SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
	        	 SharedPreferences.Editor editor;
	        	 editor = settings.edit();
	        	 editor.clear();
	        	 editor.putString("registered","no");
	        	 editor.commit();
	        	 Intent intent = new Intent(HomeActivity.this, RegistrationActivity.class);
					startActivity(intent);
					finish();
	             return true;
	         default:return super.onOptionsItemSelected(item);
	     }
	 }
	 
	private class AlogLoader extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = new Dialog(HomeActivity.this);
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.miniloading);
			ImageView image = (ImageView)dialog.findViewById(R.id.loadinglogo);
			TextView text = (TextView)dialog.findViewById(R.id.loadingtext);
			
			image.setImageBitmap(null);
			 
			image.setBackgroundResource(R.drawable.loadingscreenanimation);
				
			final AnimationDrawable splashAnimation = (AnimationDrawable) image.getBackground();
			image.post(new Runnable() {
				public void run() 
				{
					if ( splashAnimation != null ) splashAnimation.start();
				}
			});
			
			dialog.setCancelable(false);
			text.setText("Loading Adventurer's Log..");
			dialog.show();
		}

		protected String doInBackground(String... params)
		{
			String result = "";
			try 
			{
				/** Handling XML */
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();

				/** Send URL to parse XML Tags */
				username = username.replace(" ", "+");
				URL sourceUrl = new URL
				("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + username);
				/**
				 * Create handler to handle XML Tags ( extends
				 * DefaultHandler )
				 */
				//MyXMLHandler myXMLHandler = new MyXMLHandler();
				xr.setContentHandler(new MyXMLHandler());
				xr.parse(new InputSource(sourceUrl.openStream()));
				result = "completed";
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				result = "error";
			}
				/** Get result from MyXMLHandler XMLlist Object */
				alogList = MyXMLHandler.xMLList;
				return result;
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				Intent in = new Intent(HomeActivity.this, Alog.class);
				Bundle b = new Bundle();
			
				b.putStringArrayList("titleList", alogList.getTitle());
				b.putStringArrayList("linkList", alogList.getLink());
				b.putStringArrayList("descriptionList", alogList.getDescription());
				b.putStringArrayList("dateList",alogList.getDate());
				b.putStringArrayList("categories", alogList.getCategory());
				in.putExtras(b);
			
				startActivity(in);
				dialog.dismiss();
				dialog = null;
			}
		}
	}
	private class NewsLoader extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = new Dialog(HomeActivity.this);
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.miniloading);
			ImageView image = (ImageView)dialog.findViewById(R.id.loadinglogo);
			TextView text = (TextView)dialog.findViewById(R.id.loadingtext);
			
			image.setImageBitmap(null);
			 
			image.setBackgroundResource(R.drawable.loadingscreenanimation);
				
			final AnimationDrawable splashAnimation = (AnimationDrawable) image.getBackground();
			image.post(new Runnable() {
				public void run() 
				{
					if ( splashAnimation != null ) splashAnimation.start();
				}
			});
			
			dialog.setCancelable(false);
			text.setText("Loading News ..");
			dialog.show();
		}
		@Override
		protected String doInBackground(String... params)
		{
			String result = "completed";
			try 
			{
				/** Handling XML */
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();

				/** Send URL to parse XML Tags */
				URL sourceUrl = new URL("http://services.runescape.com/m=news/latest_news.rss");
				/**
				 * Create handler to handle XML Tags ( extends
				 * DefaultHandler )
				 */
				//MyXMLHandler myXMLHandler = new MyXMLHandler();
				xr.setContentHandler(new MyXMLHandler());
				xr.parse(new InputSource(sourceUrl.openStream()));
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
				result = "error";
				//Log.i("EXCEPTION:","HomeActivity.java, line 121 - xml not parsed");
			}
			/** Get result from MyXMLHandler XMLlist Object */
			newsList = MyXMLHandler.xMLList;
			return result;
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				Intent in = new Intent(HomeActivity.this, News.class);
				Bundle b = new Bundle();
				
				b.putStringArrayList("titleList", newsList.getTitle());
				b.putStringArrayList("linkList", newsList.getLink());
				b.putStringArrayList("descriptionList", newsList.getDescription());
				b.putStringArrayList("dateList",newsList.getDate());
				b.putStringArrayList("categories", newsList.getCategory());
				in.putExtras(b);
				
				dialog.dismiss();
				startActivity(in);
			}
		}
	}
	public void onResume()
	{
		super.onResume();
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		String registered = settings.getString("registered","null");
		if(registered != null && registered.equals("no"))
		{
			finish();
		}
	}
}