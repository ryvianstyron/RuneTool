package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Dialog;
import android.app.ListActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class GeneralCatList extends ListActivity
{
	int titleToSet = R.drawable.buttonback3;
	Button img;
	GeItem geItem;
	int category = 0; // Which category is it
	String categoryTitle = "";
	ArrayList<HashMap<String, Object>> list;
	ArrayList<String> letters;
	ArrayList<Integer> items;
	ArrayList<Integer> pages;
	ArrayList<GeItem> geItems;
	static HashMap<String, Integer> letterAndPages = new HashMap<String, Integer>();
	ArrayList<String> images;
	String[] itemsInCategory;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gehome);
		display("Got into GeneralCatList!!!");

		img = (Button) findViewById(R.id.gehometitle);
		img.setBackgroundResource(titleToSet);
		letters = getIntent().getExtras().getStringArrayList("letterList");
		items = getIntent().getExtras().getIntegerArrayList("itemList");
		category = getIntent().getExtras().getInt("category");
		categoryTitle = getIntent().getExtras().getString("categoryTitle");
		// setting how many pages there are in each category letter: example a
		// has 14 items so 2 pages
		img.setText(categoryTitle);
		pages = new ArrayList<Integer>();
		for (int i = 0; i < letters.size(); i++)
		{
			// Log.i("SETTING", "Letter: " + letters.get(i)+ " Items: " +
			// items.get(i));
			int noOfPages = 0;
			if (items.get(i) == 0)
			{
				// Log.i("SETTING2", "Getting in here for Letter: " +
				// letters.get(i));
				noOfPages = 0;
			} else if (items.get(i) <= 12 && items.get(i) >= 1)
			{
				noOfPages = 1;
			} else if (items.get(i) > 12)
			{
				noOfPages = Math.round(items.get(i) / 12);
			}
			pages.add(i, noOfPages);
		}
		updateItemsInCategory();

		list = new ArrayList<HashMap<String, Object>>();
		SimpleAdapter adapter = new SimpleAdapter(this, list,
				R.layout.catlistitem, new String[] { "title" },
				new int[] { R.id.catTitle });

		populateList();
		setListAdapter(adapter);
	}

	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 1000202).show();
	}

	public void populateList()
	{
		ImageView image = (ImageView) findViewById(R.id.catImage);
		for (int i = 0; i < geItems.size(); i++)
		{
			HashMap<String, Object> temp = new HashMap<String, Object>();
			temp.put("title", geItems.get(i).getName());
			list.add(temp);
		}
	}

	private String convertStreamToString(InputStream in)
			throws UnsupportedEncodingException
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,
				"UTF-8"));
		StringBuilder sb = new StringBuilder();
		String line = null;

		try
		{
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			try
			{
				in.close();
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	public void updateItemsInCategory()
	{
		String id = "";
		String errorMessage = "";
		images = new ArrayList<String>();
		String urlTillCat = "http://services.runescape.com/m=itemdb_rs/api/catalogue/items.json?category=";
		String urlTillLetter = "&alpha=";
		String urlTillPage = "&page=";
		String letter = "0";
		int page = 0;
		String json = "";
		geItems = new ArrayList<GeItem>();
		try
		{
			for (int i = 0; i < letters.size(); i++)
			{
				// if no pages have been set, means there are no items there,
				// continue
				if (pages.get(i) == 0 || letters.get(i).contains("#"))
				{
					continue;
				} 
				else
				{
					// Go thru and load the current letter category + current
					// alphabet
					JSONArray jItem = null;
					// Get current letter to use and total pages in that letter
					letter = letters.get(i);
					page = pages.get(i);
					// Go thru all pages
					for (int j = 1; j < page + 1; j++)
					{
						errorMessage = "Starting to parse alphabet/cat url at i= " + i + "at j =" + j;
						String urlToLoad = urlTillCat + category+ urlTillLetter + letter + urlTillPage+ pages.get(j);
						// TEST HERE
						Log.i("URL TO LOAD (C:L:P)= (" + category + ":"+ letter + ":" + page + ")", urlToLoad);
						URLConnection feedUrl = new URL(urlToLoad).openConnection();
						InputStream in = feedUrl.getInputStream();
						json = convertStreamToString(in);
						JSONObject jsonObj = new JSONObject(json);
						jItem = jsonObj.getJSONArray("items");
						for (int k = 0; k < jItem.length(); k++)
						{
							errorMessage = "in k loop";
							
							GeItem geItem = new GeItem();
							JSONObject item = jItem.getJSONObject(k);
							
							geItem.setName(item.getString("name"));
							geItem.setDescription(item.getString("description"));
							geItem.setType(item.getString("type"));
							geItem.setId(item.getInt("id"));
							geItem.setIconUrl(item.getString("icon_large"));
							//Log.i("ICON URL IS:", item.getString("icon_large"));
							
							JSONObject pItem = item.getJSONObject("current");
							geItem.setPriceCurrent(pItem.getString("price"));
							
							pItem = item.getJSONObject("today");
							geItem.setPriceToday(pItem.getString("price"));
							geItems.add(geItem);
						}
					}
				}
			}
		} 
		catch (Exception e)
		{
			Log.e("Error Message:",errorMessage, e);
		}
		// Check if it worksim g
		for (int i = 0; i < geItems.size(); i++)
		{
			Log.i("Name(" + i + "):", geItems.get(i).getName());
			Log.i("Desc(" + i + "):", geItems.get(i).getDescription());
			Log.i("Type(" + i + "):", geItems.get(i).getType());
			Log.i("IconURL(" + i + "):", geItems.get(i).getIconUrl());
			Log.i("CPrice(" + i + "):", geItems.get(i).getPriceCurrent());
			Log.i("TPrice(" + i + "):", geItems.get(i).getPriceToday());
		}
	}

	public void onBackPressed()
	{
		super.onBackPressed();
		this.finish();
	}

	public void onListItemClick(ListView l, View v, int position, long id) 
	{
		//display("Item" + position + ":clicked!");
		super.onListItemClick(l, v, position, id);
		
		final Dialog dialog = new Dialog(GeneralCatList.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.showgedesc);
        
        WebView img;
    	TextView nametxt;
    	TextView desctxt;
    	TextView typetxt;
    	TextView urltxt;
    	TextView pctxt;
    	TextView tctxt;
    	TextView idtxt;
    	Button dismiss;
    	
    	String name = geItems.get(position).getName();
    	String desc = geItems.get(position).getDescription();
    	String type = geItems.get(position).getType();
    	String url =geItems.get(position).getIconUrl();
    	String pc = geItems.get(position).getPriceCurrent();
    	String tc = geItems.get(position).getPriceToday();
    	String id2 = geItems.get(position).getId();
    	if(tc.contains("0"))
		{
			tc = "No Change";
		}
    	nametxt = (TextView)dialog.findViewById(R.id.itemName);
		desctxt = (TextView)dialog.findViewById(R.id.desc);
		typetxt = (TextView)dialog.findViewById(R.id.type);
		idtxt = (TextView)dialog.findViewById(R.id.id);
		pctxt = (TextView)dialog.findViewById(R.id.current);
		tctxt = (TextView)dialog.findViewById(R.id.today);
		dismiss = (Button)dialog.findViewById(R.id.dismiss);
		img = (WebView)dialog.findViewById(R.id.webview);
		
		//build image tag
		url = "\"" + url + "\""; //surround url with quotes
		Log.i("URL WITH QUOTES",url);
	    String html = "<div style=\"text-align:center;\"><a href=" + url;
	    html = html + "target=\"_blank\">";
	    html = html + "<img src=" + url + ">" + "<img src=" + url;
	    html = html + "></a></div>";
	    html = "<img src = " + url + "></a>";
	    //html = "<div style=\"text-align:center;\"><a href=\"http://services." +
	    		//"runescape.com/m=rswikiimages/en/2012/5/monkey_cape-24170202.jpg\" target=\"_blank\">" + 
	   // "<img src=\"http://services.runescape.com/m=rswikiimages/en/2012/5/monkey_cape_thumb-24170208.gif\"></a></div>";
	    img.loadDataWithBaseURL(null,html,"text/html","utf-8",null);
		img.setBackgroundColor(0);
		img.getSettings().setDefaultZoom(WebSettings.ZoomDensity.CLOSE);
		img.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		img.setVerticalScrollBarEnabled(false);
		//img.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
		//img.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
		nametxt.setText(name);
		desctxt.setText("Description: " + desc);
		typetxt.setText("Type: " + type);
		pctxt.setText("Current Price: " + pc);
		tctxt.setText("Price Change Today: " + tc);
		idtxt.setText("Item ID: " + id);
		OnClickListener dismissButton = new OnClickListener()
		{
			public void onClick(View v)
			{
				 dialog.dismiss();
			}
		};
		dismiss.setOnClickListener(dismissButton);
		dialog.show();
        
        
		/*Intent intent = new Intent (GeneralCatList.this,ShowGeItem.class);
		Bundle b = new Bundle();
		b.putString("name", geItems.get(position).getName());
		b.putString("desc",geItems.get(position).getDescription());
		b.putString("type",geItems.get(position).getType());
		b.putString("url",geItems.get(position).getIconUrl());
		Log.i("ICON URL IS GETTING:", geItems.get(position).getIconUrl());
		b.putString("pc",geItems.get(position).getPriceCurrent());
		b.putString("tc",geItems.get(position).getPriceToday());
		b.putString("id", geItems.get(position).getId());
		intent.putExtras(b);
		startActivity(intent);*/
	}

}
