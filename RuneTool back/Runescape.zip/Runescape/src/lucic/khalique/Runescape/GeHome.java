package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class GeHome extends ListActivity
{
	int titleToSet = R.drawable.buttonback3;
	Button img;
	ArrayList<HashMap<String, Object>> list;
	static HashMap<String, Integer> images = new HashMap<String, Integer>();
	private ArrayList<String> letter; 
	private ArrayList<Integer> items; 
	String[] cats = 
	{ 		"Miscellaneous", // 0
			"Ammo", // 1
			"Arrows", // 2
			"Bolts", // 3
			"Construction Materials", // 4
			"Construction Projects", // 5
			"Cooking Ingredients", // 6
			"Costumes", // 7
			"Crafting Materials", // 8
			"Familiars", // 9
			"Farming Produce", // 10
			"Fletching Materials", // 11
			"Food and Drink", // 12
			"Herblore Materials", // 13
			"Hunting Equipment", // 14
			"Hunting Produce", // 15
			"Jewellery", // 16
			"Mage Armour", // 17
			"Mage Weapons", // 18
			"Melee Armour - Low Level", // 19
			"Melee Armour - Mid Level", // 20
			"Melee Armour - High Level",// 21
			"Melee Weapons - Low Level",// 22
			"Melee Weapons - Mid Level",// 23
			"Melee Weapons - High Level",// 24
			"Mining and Smithing", // 25
			"Potions", // 26
			"Prayer Armour", // 27
			"Prayer Materials", // 28
			"Range Armour", // 29
			"Range Weapons", // 30
			"Runecrafting", // 31
			"Runes, Spells and Teleports",// 32
			"Seeds", // 33
			"Summoning Scrolls", // 34
			"Tools and Containers", // 35
			"Woodcutting Product" // 36
	};

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gehome);
		img = (Button)findViewById(R.id.gehometitle);
		img.setBackgroundResource(titleToSet);
		img.setText("Categories");

		list = new ArrayList<HashMap<String, Object>>();
		SimpleAdapter adapter = new SimpleAdapter(this, list,
				R.layout.gelistitem, new String[] { "image", "title", },
				new int[] { R.id.catImage, R.id.catTitle });
		populateList();
		setListAdapter(adapter);
	}
	public void populateList()
	{
		initCatMap();
		for (int i = 0; i < cats.length; i++)
		{
			HashMap<String, Object> temp = new HashMap<String, Object>();
			int drawable = R.drawable.item;
			/*
			 * for (Map.Entry<String, Integer> entry : images.entrySet()) {
			 * String key = entry.getKey(); Object value = entry.getValue();
			 * if(titles.get(i).contains(entry.getKey())) { drawable =
			 * entry.getValue(); break; } else drawable = R.drawable.item; }
			 */
			temp.put("title", cats[i]);
			temp.put("image", drawable);
			list.add(temp);
		}
	}
	public void onBackPressed()
	{
		super.onBackPressed();
		this.finish();
	}

	public void onListItemClick(ListView l, View v, int position, long id)
	{
		super.onListItemClick(l, v, position, id);
		String errorMessage = "";
		String urlToLoad = "http://services.runescape.com/m=itemdb_rs/api/catalogue/category.json?category=";
		int categoryToLoad = position;
		urlToLoad = urlToLoad + categoryToLoad;
		try 
		{
			// Send URL to parse JSON Objects
			JSONArray jItem = null;
			
			errorMessage = "Loading url at position = " + position;
			// Access and retrieve JSON file to be parsed
			URLConnection feedUrl = new URL(urlToLoad).openConnection();
			InputStream in = feedUrl.getInputStream();
			String json = convertStreamToString(in);
			Log.i("JASON", json);
				
			//Parse JSON 
			JSONObject jsonObj = new JSONObject(json); 
				
			//JSONObject obj = jsonObj.getJSONObject("types"); 
			//jItem = obj.getJSONArray("alpha"); 
			jItem = jsonObj.getJSONArray("alpha");
	 
			errorMessage = "Parsing contents of url at position = " + position;
			letter = new ArrayList<String>();
			items = new ArrayList<Integer>(); 
			for (int i = 0; i < jItem.length(); i++)
			{ 
				JSONObject item = jItem.getJSONObject(i);
				setLetter(item.getString("letter"));
				setItem(Integer.parseInt(item.getString("items")));
			} 
			
			Intent intent = new Intent(GeHome.this, GeneralCatList.class);
			Bundle b = new Bundle();
			b.putStringArrayList("letterList", getLetters());
			b.putIntegerArrayList("itemList", getItems());
			b.putInt("category", position);
			b.putString("categoryTitle", cats[position]);
			intent.putExtras(b);
			startActivity(intent);
		}
		catch (Exception e) 
		{
			Log.e("Error Message", errorMessage, e);
		}
	}

	public void initCatMap()
	{

	}

	public void setLetter(String alphabet)
	{
		letter.add(alphabet);
	}

	public void setItem(int total)
	{
		items.add(total);
	}

	public ArrayList<String> getLetters()
	{
		return letter;
	}

	public ArrayList<Integer> getItems()
	{
		return items;
	}
	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 1000202).show();
	}

	private String convertStreamToString(InputStream in)throws UnsupportedEncodingException
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(in,
				"UTF-8"));
		StringBuilder sb = new StringBuilder();
		String line = null;

		try
		{
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		} finally
		{
			try
			{
				in.close();
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return sb.toString();
	}
}
