package lucic.khalique.Runescape;

import java.net.URL;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends Activity
{
	String username = "";
	Button alog;
	Button news;
	Button forumTime;
	Button hiScores;
	Button ge;
	EditText usernameEntry;
	SharedPreferences preferences;
	ImageView image;
	TextView usernametv;
	
	private XMLList newsList;
	private XMLList alogList;
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);

		forumTime = (Button)findViewById(R.id.timeButton);
		news = (Button) findViewById(R.id.newsButton);
		alog = (Button) findViewById(R.id.alogButton);
		usernameEntry = (EditText) findViewById(R.id.username);
		hiScores = (Button)findViewById(R.id.hiScoresButton);
		ge = (Button)findViewById(R.id.geButton);
	
		//For Adventurer's Log. Requires username Entry
		OnClickListener hiScoresListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				username = usernameEntry.getText().toString();
				if(username.equals("Enter Username") ||
						username.equals(""))
				{
					display("Please Enter a valid username");
				}
					
				else
				{
					//username = usernameEntry.getText().toString();
					Intent intent = new Intent(HomeActivity.this, HighScores2.class);
					Bundle b = new Bundle();
					b.putString("username",username);
					intent.putExtras(b);
					startActivity(intent);
				}
			}
		};
		OnClickListener geListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, GeHome.class);
				startActivity(intent);
			}
		};
		OnClickListener alogListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				username = usernameEntry.getText().toString();
				if(username.equals("Enter Username") ||
						username.equals(""))
				{
					display("Please Enter a valid username");
				}
				else
				{	
					try 
					{
						/** Handling XML */
						SAXParserFactory spf = SAXParserFactory.newInstance();
						SAXParser sp = spf.newSAXParser();
						XMLReader xr = sp.getXMLReader();

						/** Send URL to parse XML Tags */
						URL sourceUrl = new URL
						("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + username);
						/**
						 * Create handler to handle XML Tags ( extends
						 * DefaultHandler )
						 */
						//MyXMLHandler myXMLHandler = new MyXMLHandler();
						xr.setContentHandler(new MyXMLHandler());
						xr.parse(new InputSource(sourceUrl.openStream()));
					} 
					catch (Exception e) 
					{
						e.printStackTrace();
						//Log.i("EXCEPTION:","HomeActivity.java, line 121 - xml not parsed");
					}
					/** Get result from MyXMLHandler XMLlist Object */
					alogList = MyXMLHandler.xMLList;

					// Send the parsed data to the  news listview
					Intent in = new Intent(HomeActivity.this, Alog.class);
					Bundle b = new Bundle();
				
					b.putStringArrayList("titleList", alogList.getTitle());
					b.putStringArrayList("linkList", alogList.getLink());
					b.putStringArrayList("descriptionList", alogList.getDescription());
					b.putStringArrayList("dateList",alogList.getDate());
					b.putStringArrayList("categories", alogList.getCategory());
					in.putExtras(b);
				
					startActivity(in);
				}
			}
		};
		//For news button
		OnClickListener newsListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				try 
				{
					/** Handling XML */
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();

					/** Send URL to parse XML Tags */
					URL sourceUrl = new URL("http://services.runescape.com/m=news/latest_news.rss");
					/**
					 * Create handler to handle XML Tags ( extends
					 * DefaultHandler )
					 */
					//MyXMLHandler myXMLHandler = new MyXMLHandler();
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					//Log.i("EXCEPTION:","HomeActivity.java, line 121 - xml not parsed");
				}
				/** Get result from MyXMLHandler XMLlist Object */
				newsList = MyXMLHandler.xMLList;

				// Send the parsed data to the  news listview
				Intent in = new Intent(HomeActivity.this, News.class);
				Bundle b = new Bundle();
				
				b.putStringArrayList("titleList", newsList.getTitle());
				b.putStringArrayList("linkList", newsList.getLink());
				b.putStringArrayList("descriptionList", newsList.getDescription());
				b.putStringArrayList("dateList",newsList.getDate());
				b.putStringArrayList("categories", newsList.getCategory());
				in.putExtras(b);
				
				startActivity(in);
			}
		};
		//For Forum time
		OnClickListener timeListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, Time.class);
				startActivity(intent);
			}
		};
		//Attaching listeners
		forumTime.setOnClickListener(timeListener);
		alog.setOnClickListener(alogListener);
		news.setOnClickListener(newsListener);
		hiScores.setOnClickListener(hiScoresListener);
		ge.setOnClickListener(geListener);
	}

	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 300000).show();
	}
}