package lucic.khalique.Runescape;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class RSSHandler extends DefaultHandler {

    RSSFeed _feed;
    RSSItem _item;
    String _lastElementName = "";
    boolean bFoundChannel = false;
    final int RSS_TITLE = 1;
    final int RSS_LINK = 2;
    final int RSS_DESCRIPTION = 3;
    final int RSS_CATEGORY = 4;
    final int RSS_PUBDATE = 5;

    StringBuilder buff = null;

    int depth = 0;
    int currentstate = 0;

    /*
     * Constructor
     */
    RSSHandler() {
    }

    /*
     * getFeed - this returns our feed when all of the parsing is complete
     */
    RSSFeed getFeed() {
	return _feed;
    }

    public void startDocument() throws SAXException {
	// initialize our RSSFeed object - this will hold our parsed contents
	_feed = new RSSFeed();
	// initialize the RSSItem object - you will use this as a crutch to grab
	// the info from the channel
	// because the channel and items have very similar entries..
	_item = new RSSItem();
	Log.i("RSSReader", "start document");

    }

    public void endDocument() throws SAXException {
    }

    public void startElement(String namespaceURI, String localName,
	    String qName, Attributes atts) throws SAXException {
	depth++;
	Log.i("RSSReader", "start element: " + localName);
	if (localName.equals("channel")) {
	    currentstate = 0;
	    Log.i("RSSReader", "Found channel");
	    return;
	}
	if (localName.equals("image")) {
	    // record our feed data - you temporarily stored it in the item :)
	    _feed.setTitle(_item.getTitle());
	    _feed.setPubDate(_item.getPubDate());
	    Log.i("RSSReader", "Found image");
	}
	if (localName.equals("item")) {
	    // create a new item
	    _item = new RSSItem();
	    Log.i("RSSReader", "Found item");
	    return;
	}
	if (localName.equals("title")) {
	    currentstate = RSS_TITLE;
	    Log.i("RSSReader", "Found Title");
	    buff = new StringBuilder();
	    return;
	}
	if (localName.equals("description")) {
	    currentstate = RSS_DESCRIPTION;
	    Log.i("RSSReader", "Found description");
	    buff = new StringBuilder();
	    return;
	}
	if (localName.equals("link")) {
	    currentstate = RSS_LINK;
	    Log.i("RSSReader", "Found link");
	    buff = new StringBuilder();
	    return;
	}
	if (localName.equals("category")) {
	    currentstate = RSS_CATEGORY;
	    Log.i("RSSReader", "Found category");
	    buff = new StringBuilder();
	    return;
	}
	if (localName.equals("pubDate")) {
	    currentstate = RSS_PUBDATE;
	    Log.i("RSSReader", "Found pubdate");
	    buff = new StringBuilder();
	    return;
	}
	// if you don't explicitly handle the element, make sure you don't wind
	// up erroneously storing a newline or other bogus data into one of our
	// existing elements
	currentstate = 0;
    }

    public void endElement(String namespaceURI, String localName, String qName)
	    throws SAXException {
	Log.i("RSSReader", "end element: " + localName);
	depth--;
	switch (currentstate) {
	case RSS_TITLE:
	    _item.setTitle(buff.toString());
	    currentstate = 0;
	    Log.i("RSSReader", "in title: " + buff.toString());
	    break;
	case RSS_LINK:
	    _item.setLink(buff.toString());
	    currentstate = 0;
	    break;
	case RSS_DESCRIPTION:
	    _item.setDescription(buff.toString());
	    currentstate = 0;
	    break;
	case RSS_CATEGORY:
	    _item.setCategory(buff.toString());
	    currentstate = 0;
	    break;
	case RSS_PUBDATE:
	    _item.setPubDate(buff.toString());
	    currentstate = 0;
	    break;
	default:
	    // Log.i("RSSReader", "fails:" + currentstate);
	    //return;
	}
	buff = null;
	if (localName.equals("item")) {
	    // add our item to the list!
	    _feed.addItem(_item);
	    return;
	}
    }

    public void characters(char ch[], int start, int length) {
	if (buff != null) {
	    for (int i = start; i < start + length; i++) {
		buff.append(ch[i]);
	    }

	}

    }
}
