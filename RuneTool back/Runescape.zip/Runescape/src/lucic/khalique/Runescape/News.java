package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class News extends ListActivity
{
	static HashMap<String, Integer> images = new HashMap<String, Integer>();
	TextView title;
	TextView date;
	TextView desc;
	Button image;
	Button moreinfo;
	Button lessinfo;
	TextView link;
	TextView info;
	String result ="";
	int drawable;
	TextView category;
	String temp = "didnt load yet";
	Boolean clicked = false;
	ScrollView scroll;
	ArrayList<HashMap<String,Object>> list;
	
	private static ArrayList<String> titles;
    private static ArrayList<String> descriptions;
    private static ArrayList<String> links;
    private static ArrayList<String> dates;
    private static ArrayList<String> categories;
	
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);       
        setContentView(R.layout.listview);
        list = new ArrayList<HashMap<String,Object>>();
        SimpleAdapter adapter = new SimpleAdapter(
        	    this,
        	    list,
        	    R.layout.listitem,
        	    new String[] {"image","title","date", "category"},
        	    new int[] {R.id.newsImage,R.id.newsTitle, R.id.dateText, R.id.categoryText}
        	    );
        
        Bundle b = this.getIntent().getExtras();
        titles = b.getStringArrayList("titleList");
        descriptions = b.getStringArrayList("descriptionList");
        links = b.getStringArrayList("linkList");
        dates = b.getStringArrayList("dateList");
        categories = b.getStringArrayList("categories");
        populateList();
        setListAdapter(adapter);
		
	}
	public void onListItemClick(ListView l, View v, int position, long id) 
	{
		super.onListItemClick(l, v, position, id);
	    initNewsMap();
	    final int spot = position;
		String titleText = null;
        String dateText = null;
        String description = null;
        String linkText = null;
        String categoryText = null;
        String infoText = null;
        
        final Dialog dialog = new Dialog(News.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.showdescription);
        	
        dialog.setCancelable(true);

        title = (TextView)dialog.findViewById(R.id.title);
        date = (TextView)dialog.findViewById(R.id.date);
        desc = (TextView)dialog.findViewById(R.id.desc);
        link = (TextView)dialog.findViewById(R.id.link);
        image =(Button)dialog.findViewById(R.id.newsImage);
        info = (TextView)dialog.findViewById(R.id.infodetail);
        moreinfo = (Button)dialog.findViewById(R.id.moreinfo);
        category = (TextView)dialog.findViewById(R.id.category);
        scroll = (ScrollView)dialog.findViewById(R.id.scroll);
        lessinfo = (Button)dialog.findViewById(R.id.lessinfo);
        
        link.setVisibility(View.GONE);
        lessinfo.setVisibility(View.GONE);
		category.setVisibility(View.GONE);
		
		scroll.setVisibility(View.GONE);
		HttpClient httpclient = new DefaultHttpClient();
		HttpGet httpget = new HttpGet(links.get(position));
		
		try
		{
			// Execute HTTP Post Request
			HttpResponse response = httpclient.execute(httpget);

			// Extract the page content returned from the response
			BufferedReader in = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			StringBuffer sb = new StringBuffer("");
			String line = "";
			String NL = System.getProperty("line.separator");
			while ((line = in.readLine()) != null)
			{
				sb.append(line + NL);
			}
			in.close();
			result = sb.toString();
		
			String array1[];
			String array2[];
			array1 = result.split("<div class=\"Content\">");
			int divCounter = 0;
			Boolean done = false;
			StringBuffer builder = new StringBuffer();
			//array1[1] = array1[1].replaceAll("'", "");
			String divString[] = array1[1].split("</div>");
			//StringTokenizer st = new StringTokenizer(array1[1],"</div>");
			int length = divString.length;
			for(int i = 0; i < length && !done; i++)
			{
				Log.i("dIV STRING" , divString[i]);
			
				String temp = divString[i];
				divCounter = temp.indexOf("<div");
				if(divCounter== -1)
				{
					builder.append(temp);
					done = true;
					Log.i("TEMP IF", temp);
				}
				else
				{
					builder.append(temp);
					builder.append("</div>");
					Log.i("TEMP ELSE", temp);
				}
			}
			// put in extracting the video link from the iframe here. IF it contains an iframe!
			
			result = builder.toString();
			
		} 
		catch (ClientProtocolException e)
		{
			Log.d("ERROR", "ClientProtocolException=" + e);
			System.err.println("ClientProtocolException=" + e);
		} catch (IOException e)
		{
			Log.d("ERROR", "IOException=" + e);
			System.err.println("IOException=" + e);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		/** Get result from MyXMLHandler SitlesList Object */
		//////////////////Setting info here//////////////////
		categoryText = categories.get(position);
		for (Map.Entry<String, Integer> entry : images.entrySet()) 
		{
		    String key = entry.getKey();
		    Object value = entry.getValue();
		    if(categoryText.contains(entry.getKey()))
		    {
		    	drawable = entry.getValue();
		    	break;
		    }
		    else drawable = R.drawable.item;
		}
		titleText = titles.get(position);
        dateText = dates.get(position);
        
        description = descriptions.get(position);
        String array [];
    	int index = 0;
    	if (description.contains("/>"))
		{
    		array = description.split("/>");
    		index = description.indexOf("10;");
    		description = (array[array.length - 1].trim());
		}
        
        linkText = links.get(position);
        
        image.setBackgroundResource(drawable);
        title.setText(titleText);
        date.setText(dateText);
        desc.setText(description);
        link.setText(linkText + " ");
        
        final Button moreInfo = (Button)dialog.findViewById(R.id.moreinfo);
        final Button back = (Button) dialog.findViewById(R.id.back);
        back.setOnClickListener(new OnClickListener() {
        @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        moreInfo.setOnClickListener(new OnClickListener() 
        {
        	@Override
	        public void onClick(View v) 
	        {
        		Intent intent = new Intent(News.this, WebInfo.class);
        		Bundle b = new Bundle();
				b.putString("webInfo",result);
				b.putString("category",categories.get(spot));
				b.putString("title",titles.get(spot));
				b.putString("date",dates.get(spot));
				intent.putExtras(b);
				startActivity(intent);
	        }
        });
        final Button lessInfo = (Button)dialog.findViewById(R.id.lessinfo);
        lessInfo.setOnClickListener(new OnClickListener() {
        @Override
        public void onClick(View v) 
        {
        	moreInfo.setVisibility(View.VISIBLE);
			scroll.setVisibility(View.GONE);
			desc.setVisibility(View.VISIBLE);
			link.setVisibility(View.GONE);
			back.setVisibility(View.VISIBLE);
			lessInfo.setVisibility(View.GONE);
        }
        });
        
        dialog.show();
	   
	}
	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 1000202).show();
	}
	
	public  void populateList()
	{
		initNewsMap();
		for (int i = 0; i < titles.size(); i++) 
		{
	    		HashMap<String, Object> temp = new HashMap<String, Object>();
	    		int drawable = R.drawable.item;
	    		String category = categories.get(i);
	    		for (Map.Entry<String, Integer> entry : images.entrySet()) 
				{
				    String key = entry.getKey();
				    Object value = entry.getValue();
				    if(category.contains(entry.getKey()))
				    {
				    	drawable = entry.getValue();
				    	break;
				    }
				    else drawable = R.drawable.item;
				}
	    		temp.put("title", titles.get(i));
	    		temp.put("image", drawable);
	    		temp.put("date", dates.get(i));
	    		temp.put("category", categories.get(i));
	    		list.add(temp);
	    }
	}
	public void initNewsMap()
	{
		images.put("Behind the Scenes News",R.drawable.bts);
		images.put("Customer Support News",R.drawable.cs);
		images.put("Game Update News",R.drawable.ga);
		images.put("Website News",R.drawable.db);
		images.put("Technical News",R.drawable.tn);
	}
	public void onBackPressed()
	{
		super.onBackPressed();
		this.finish();
	}
}
