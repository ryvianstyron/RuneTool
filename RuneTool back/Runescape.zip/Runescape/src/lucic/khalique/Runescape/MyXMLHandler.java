package lucic.khalique.Runescape;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class MyXMLHandler extends DefaultHandler
{
	public static XMLList xMLList;
	Boolean currentElement = false;
	String currentValue = null;
	
	Boolean inTitle = false;
	Boolean inDescription = false;
	Boolean inItem = false;
	Boolean inDate = false;
	Boolean inLink = false;
	Boolean inCategory = false;
	
	StringBuilder buff = null;
	
	public MyXMLHandler()
	{
		xMLList = new XMLList();
	}
	// All methods auto called in this order - start, characters, end
	/*
	 * Called when an xml tag starts
	 * imgView.setImageResource(R.drawable.newImage);
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes)
	{
		Log.i("START",localName);
		if(xMLList == null)
		{
			xMLList = new XMLList();
		}
		if (inItem) 
		{
			//Log.i("IN ITEM","SUCCESS");
	    	if (localName.equals("title")) 
	    	{
	    		//Log.i("IN TITLE",localName);
	    		inTitle = true;
	    		buff = new StringBuilder();
	    	}
	    	if (localName.equals("description")) 
	    	{
	    		//Log.i("IN DESCRIPTION","");
	    		inDescription = true;
	    		buff = new StringBuilder();
	    	}
	    	if (localName.equals("link")) 
	    	{
	    		//Log.i("IN LINK","");
	    		inLink = true;
	    		buff = new StringBuilder();
	    	}
	    	if (localName.equals("pubDate")) 
	    	{
	    		//Log.i("IN PUBDATE","");
	    		inDate = true;
	    		buff = new StringBuilder();
	    	}
	    	if (localName.equals("category")) 
	    	{
	    		//Log.i("IN PUBDATE","");
	    		inCategory = true;
	    		buff = new StringBuilder();
	    	}
	    }
	    else if(localName.equals("item")) 
	    {
	    	//Log.i("FOUND ITEM","");
	    	inItem = true;
	    }
	}
	/*
	 * Called when an xml tag ends
	 */
	@Override
	public void endElement(String uri, String localName, String qName)throws SAXException
	{
		Log.i("END",localName);
		if (inItem && !inTitle && !inDescription && !inLink && !inDate && !inCategory) 
	    {
			//Log.i("First if,","in item, not in title,description,link,date");
	    	inItem = false;
	    } 
	    else if (inTitle) 
	    {
	    	String check = buff.toString().trim();
	    	xMLList.setTitle(check);
	    	//Log.i("inTitle","check");
	    	inTitle = false;
	    	buff = null;
	    }
	    else if (inDescription) 
	    {
	    	String check  = buff.toString().trim();
	    	//Log.i("inDescription","check");
	    	xMLList.setDescription(check);
	    	inDescription = false;
	    	buff = null;
	    }
	    else if (inLink) 
	    {
	    	String check  = buff.toString().trim();
	    	xMLList.setLink(check);
	    	///Log.i("inLink","check");
	    	inLink = false;
	    	buff = null;
	    }
	    else if (inDate) 
	    {
	    	String check  = buff.toString().trim();
	    	check = check.substring(0,16);
	    	xMLList.setDate(check);
	    	//Log.i("inDate","check");
	    	inDate = false;
	    	buff = null;
	    }
	    else if(inCategory)
	    {
	    	String check  = buff.toString().trim();
	    	xMLList.setCategory(check);
	    	//Log.i("inDate","check");
	    	inCategory = false;
	    	buff = null;
	    }
	}

	/*
	 * Called to get tag characters
	 */
	@Override
	public void characters(char[] ch, int start, int length)throws SAXException
	{
    	if (buff != null) 
    	{
    		for (int i = start; i < start + length; i++) 
    		{
    			buff.append(ch[i]);
    		}
    	}

    }
}

