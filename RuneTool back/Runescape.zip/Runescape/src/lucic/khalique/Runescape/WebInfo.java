package lucic.khalique.Runescape;
import java.util.HashMap;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebView;
import android.widget.TextView;

public class WebInfo extends Activity
{
	static HashMap<String, Integer> images = new HashMap<String, Integer>();
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		//WebView Webview = new WebView(this);
		setContentView(R.layout.webview);
		TextView categorytv = (TextView)findViewById(R.id.category);
		TextView datetv = (TextView)findViewById(R.id.date);
		TextView titletv = (TextView)findViewById(R.id.newsTitle);

		WebView webview = (WebView)findViewById(R.id.webview);
		String webInfo = getIntent().getExtras().getString("webInfo");
		String category = getIntent().getExtras().getString("category");
		String title = getIntent().getExtras().getString("title");
		String date = getIntent().getExtras().getString("date");
		Log.i("result",webInfo);
		
		categorytv.setText(category);
		datetv.setText(date);
		titletv.setText(title);
		
		webInfo = "<body style=\"text-aling:center;color:white;font-size:17px\">" + webInfo + "</body>";
		webview.loadDataWithBaseURL(null,webInfo,"text/html","utf-8",null);
		webview.setBackgroundColor(0);
		webview.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
		webview.getSettings().setLayoutAlgorithm(LayoutAlgorithm.SINGLE_COLUMN);
	}
}
