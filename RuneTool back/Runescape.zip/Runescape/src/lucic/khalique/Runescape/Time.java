package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Time extends Activity
{
	TextView time;
	Button timeBorder;
	String result = "";
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.time);
		
		//time = (TextView)findViewById(R.id.timeText);
		timeBorder = (Button)findViewById(R.id.timeBorder);
		timeBorder.setText("");
		
		String url = "http://services.runescape.com/m=toolbar/jagextime2.ws";
		
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url);
		HttpGet httpget = new HttpGet(url);
		result = ""; // result of http Post
		
		//Log.d("Line 40(Time.java) result is:", result);
		try
		{
			// Execute HTTP Post Request
			HttpResponse response = httpclient.execute(httpget);

			// Extract the page content returned from the response
			BufferedReader in = new BufferedReader(new InputStreamReader(
					response.getEntity().getContent()));
			StringBuffer sb = new StringBuffer("");
			String line = "";
			String NL = System.getProperty("line.separator");
			while ((line = in.readLine()) != null)
			{
				sb.append(line + NL);
			}
			in.close();
			String array1[];
			String array2[];
			result = sb.toString();
			array1 = result.split("<DEFAULT_BUTTON_TEXT>");
			array2 = array1[1].split("</DEFAULT_BUTTON_TEXT>");
			String result2 = array2[0];
			result2 = result2.substring(9,14);
			//time.setText(result2);
			timeBorder.setText(result2);
			
		} 
		catch (ClientProtocolException e)
		{
			Log.d("ERROR", "ClientProtocolException=" + e);
			System.err.println("ClientProtocolException=" + e);
		} catch (IOException e)
		{
			Log.d("ERROR", "IOException=" + e);
			System.err.println("IOException=" + e);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 300000000).show();
	}
}
