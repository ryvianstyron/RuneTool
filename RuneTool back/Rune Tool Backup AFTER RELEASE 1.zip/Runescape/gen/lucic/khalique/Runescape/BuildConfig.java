/** Automatically generated file. DO NOT MODIFY */
package lucic.khalique.Runescape;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}