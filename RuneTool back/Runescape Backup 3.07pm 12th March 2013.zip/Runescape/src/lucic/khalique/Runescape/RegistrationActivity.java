package lucic.khalique.Runescape;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class RegistrationActivity extends Activity
{
	String username = "";
	EditText memberEditText;
	SharedPreferences settings;
	SharedPreferences.Editor editor;
	LinearLayout regButtons;
	LinearLayout memberTextField;
	Button memberButton;
	Button member;
	Button free2Play;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registrationview);
		
		// Check to see if SharedPreferenes have been set ever
		SharedPreferences existingSettings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		String settingExists = existingSettings.getString("memberType",null);
		
		if(settingExists!=null) // Been set, move to home activity
		{
			Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
			startActivity(intent);
		}
		
		free2Play = (Button)findViewById(R.id.free2play);
		member = (Button) findViewById(R.id.pay2play);
		memberButton = (Button) findViewById(R.id.memberButton);
		memberEditText = (EditText)findViewById(R.id.memberEditText);
		regButtons = (LinearLayout)findViewById(R.id.accountButtons);
		memberTextField = (LinearLayout)findViewById(R.id.memberTextField);
		
		// Create Listeners
		OnClickListener free2playListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
				Bundle b = new Bundle();
				b.putString("memberType", "free2play");
				intent.putExtras(b);
				
				settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
				editor = settings.edit();
				editor.putString("memberType", "free2play");
				editor.commit();
				
				startActivity(intent);
			}
		};
		OnClickListener memberListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				regButtons.setVisibility(View.GONE);
				memberTextField.setVisibility(View.VISIBLE);
			}
		};
		OnClickListener memberButtonListener = new OnClickListener()
		{
			public void onClick(View v)
			{
				username = memberEditText.getText().toString();
				if(username.equals("Enter Member Name") ||
						username.equals(""))
				{
					display("Please Enter a valid username");
				}
					
				else
				{
					username = memberEditText.getText().toString();
					username = username.trim();
					Intent intent = new Intent(RegistrationActivity.this, HomeActivity.class);
					Bundle b = new Bundle();
					b.putString("memberType","pay2play");
					b.putString("memberName", username);
					intent.putExtras(b);
					
					
					settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
					editor = settings.edit();
					
					editor.putString("memberType", "pay2play");
					editor.putString("memberName", username);
					editor.commit();
					
					startActivity(intent);
				}
			}
		};
		//Attaching listeners
		member.setOnClickListener(memberListener);
		free2Play.setOnClickListener(free2playListener);
		memberButton.setOnClickListener(memberButtonListener);
	}

	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 300000).show();
	}
}