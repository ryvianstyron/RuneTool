package lucic.khalique.Runescape;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class HighScores extends Activity
{
	TextView oskill,olevel,orank,ototalxp; //overall
	TextView askill,alevel,arank,atotalxp; //attack
	TextView dskill,dlevel,drank,dtotalxp; //defense
	TextView sskill,slevel,srank,stotalxp;//strength
	TextView cskill,clevel,crank,ctotalxp;//constitution
	TextView rskill,rlevel,rrank,rtotalxp;//ranged
	TextView pskill,plevel,prank,ptotalxp;//prayer
	TextView mskill,mlevel,mrank,mtotalxp;//magic
	TextView coskill,colevel,corank,cototalxp;//cooking
	TextView wskill,wlevel,wrank,wtotalxp;//woodcutting
	TextView flskill,fllevel,flrank,fltotalxp;//fletching
	TextView fskill,flevel,frank,ftotalxp;//fishing
	TextView fiskill,filevel,firank,fitotalxp;//firemaking
	TextView crskill,crlevel,crrank,crtotalxp;//crafting
	TextView smskill,smlevel,smrank,smtotalxp;//smithing
	TextView miskill,milevel,mirank,mitotalxp;//mining
	TextView hskill,hlevel,hrank,htotalxp;//herblore
	TextView agskill,aglevel,agrank,agtotalxp;//agility
	TextView tskill,tlevel,trank,ttotalxp;//thieving
	TextView slskill,sllevel,slrank,sltotalxp;//slayer
	TextView faskill,falevel,farank,fatotalxp;//farming
	TextView rcskill,rclevel,rcrank,rctotalxp;//runecrafting
	TextView huskill,hulevel,hurank,hutotalxp;//hunter
	TextView ctskill,ctlevel,ctrank,cttotalxp;//construction
	TextView suskill,sulevel,surank,sutotalxp;//summoning
	TextView duskill,dulevel,durank,dutotalxp;//dungeoneering
	
	HttpClient client = new DefaultHttpClient();
	HttpGet httpGet;
	String url;
	String[] highScores;
	String[][] skills;
	String[] skillItem;
	int OVERALL = 0;
	int ATTACK = 1;
	int DEFENSE = 2;
	int STRENGTH = 3;
	int CONSTITUTION = 4;
	int RANGED = 5;
	int PRAYER = 6;
	int MAGIC = 7;
	int COOKING = 8;
	int WOODCUTTING = 9;
	int FLETCHING = 10;
	int FISHING = 11;
	int FIREMAKING = 12;
	int CRAFTING = 13;
	int SMITHING = 14;
	int MINING = 15;
	int HERBLORE = 16;
	int AGILITY = 17;
	int THIEVING = 18;
	int SLAYER = 19;
	int FARMING = 20;
	int RUNECRAFTING = 21;
	int HUNTER = 22;
	int CONSTRUCTION = 23;
	int SUMMONING = 24;
	int DUNGEONEERING = 25;
	int RANK = 0;
	int LEVEL = 1;
	int TOTALXP = 2;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.table);
		
		oskill = (TextView)findViewById(R.id.oskill);
		olevel = (TextView)findViewById(R.id.olevel);
		orank = (TextView)findViewById(R.id.orank);
		ototalxp = (TextView)findViewById(R.id.oxp);
		
		askill = (TextView)findViewById(R.id.askill);
		alevel = (TextView)findViewById(R.id.alevel);
		arank = (TextView)findViewById(R.id.arank);
		atotalxp = (TextView)findViewById(R.id.axp);
		
		dskill = (TextView)findViewById(R.id.dskill);
		dlevel = (TextView)findViewById(R.id.dlevel);
		drank = (TextView)findViewById(R.id.drank);
		dtotalxp = (TextView)findViewById(R.id.dxp);
		
		sskill = (TextView)findViewById(R.id.sskill);
		slevel = (TextView)findViewById(R.id.slevel);
		srank = (TextView)findViewById(R.id.srank);
		stotalxp = (TextView)findViewById(R.id.sxp);
		
		cskill = (TextView)findViewById(R.id.cskill);
		clevel = (TextView)findViewById(R.id.clevel);
		crank = (TextView)findViewById(R.id.crank);
		ctotalxp = (TextView)findViewById(R.id.cxp);
		
		rskill = (TextView)findViewById(R.id.rskill);
		rlevel = (TextView)findViewById(R.id.rlevel);
		rrank = (TextView)findViewById(R.id.rrank);
		rtotalxp = (TextView)findViewById(R.id.rxp);
		
		pskill = (TextView)findViewById(R.id.pskill);
		plevel = (TextView)findViewById(R.id.plevel);
		prank = (TextView)findViewById(R.id.prank);
		ptotalxp = (TextView)findViewById(R.id.pxp);
		
		mskill = (TextView)findViewById(R.id.mskill);
		mlevel = (TextView)findViewById(R.id.mlevel);
		mrank = (TextView)findViewById(R.id.mrank);
		mtotalxp = (TextView)findViewById(R.id.mxp);
		
		coskill = (TextView)findViewById(R.id.coskill);
		colevel = (TextView)findViewById(R.id.colevel);
		corank = (TextView)findViewById(R.id.corank);
		cototalxp = (TextView)findViewById(R.id.coxp);
		
		wskill = (TextView)findViewById(R.id.wskill);
		wlevel = (TextView)findViewById(R.id.wlevel);
		wrank = (TextView)findViewById(R.id.wrank);
		wtotalxp = (TextView)findViewById(R.id.wxp);
		
		flskill = (TextView)findViewById(R.id.flskill);
		fllevel = (TextView)findViewById(R.id.fllevel);
		flrank = (TextView)findViewById(R.id.flrank);
		fltotalxp = (TextView)findViewById(R.id.flxp);
		
		fskill = (TextView)findViewById(R.id.fskill);
		flevel = (TextView)findViewById(R.id.flevel);
		frank = (TextView)findViewById(R.id.frank);
		ftotalxp = (TextView)findViewById(R.id.fxp);
		
		fiskill = (TextView)findViewById(R.id.fiskill);
		filevel = (TextView)findViewById(R.id.filevel);
		firank = (TextView)findViewById(R.id.firank);
		fitotalxp = (TextView)findViewById(R.id.fixp);
		
		crskill = (TextView)findViewById(R.id.crskill);
		crlevel = (TextView)findViewById(R.id.crlevel);
		crrank = (TextView)findViewById(R.id.crrank);
		crtotalxp = (TextView)findViewById(R.id.crxp);
		
		smskill = (TextView)findViewById(R.id.smskill);
		smlevel = (TextView)findViewById(R.id.smlevel);
		smrank = (TextView)findViewById(R.id.smrank);
		smtotalxp = (TextView)findViewById(R.id.smxp);
		
		miskill = (TextView)findViewById(R.id.miskill);
		milevel = (TextView)findViewById(R.id.milevel);
		mirank = (TextView)findViewById(R.id.mirank);
		mitotalxp = (TextView)findViewById(R.id.mixp);
		
		hskill = (TextView)findViewById(R.id.hskill);
		hlevel = (TextView)findViewById(R.id.hlevel);
		hrank = (TextView)findViewById(R.id.hrank);
		htotalxp = (TextView)findViewById(R.id.hxp);
		
		agskill = (TextView)findViewById(R.id.agskill);
		aglevel = (TextView)findViewById(R.id.aglevel);
		agrank = (TextView)findViewById(R.id.agrank);
		agtotalxp = (TextView)findViewById(R.id.agxp);
		
		tskill = (TextView)findViewById(R.id.tskill);
		tlevel = (TextView)findViewById(R.id.tlevel);
		trank = (TextView)findViewById(R.id.trank);
		ttotalxp = (TextView)findViewById(R.id.txp);
		
		slskill = (TextView)findViewById(R.id.slskill);
		sllevel = (TextView)findViewById(R.id.sllevel);
		slrank = (TextView)findViewById(R.id.slrank);
		sltotalxp = (TextView)findViewById(R.id.slxp);
		
		faskill = (TextView)findViewById(R.id.faskill);
		falevel = (TextView)findViewById(R.id.falevel);
		farank = (TextView)findViewById(R.id.farank);
		fatotalxp = (TextView)findViewById(R.id.faxp);
		
		rcskill = (TextView)findViewById(R.id.rcskill);
		rclevel = (TextView)findViewById(R.id.rclevel);
		rcrank = (TextView)findViewById(R.id.rcrank);
		rctotalxp = (TextView)findViewById(R.id.rcxp);
		
		huskill = (TextView)findViewById(R.id.huskill);
		hulevel = (TextView)findViewById(R.id.hulevel);
		hurank = (TextView)findViewById(R.id.hurank);
		hutotalxp = (TextView)findViewById(R.id.huxp);
		
		ctskill = (TextView)findViewById(R.id.ctskill);
		ctlevel = (TextView)findViewById(R.id.ctlevel);
		ctrank = (TextView)findViewById(R.id.ctrank);
		cttotalxp = (TextView)findViewById(R.id.ctxp);
		
		suskill = (TextView)findViewById(R.id.suskill);
		sulevel = (TextView)findViewById(R.id.sulevel);
		surank = (TextView)findViewById(R.id.surank);
		sutotalxp = (TextView)findViewById(R.id.suxp);
		
		duskill = (TextView)findViewById(R.id.duskill);
		dulevel = (TextView)findViewById(R.id.dulevel);
		durank = (TextView)findViewById(R.id.durank);
		dutotalxp = (TextView)findViewById(R.id.duxp);
		
		
		String username = getIntent().getExtras().getString("username");
		url ="http://hiscore.runescape.com/index_lite.ws?player=" + username;
		httpGet = new HttpGet(url);
		String result = ""; // Where the resulting webpage will be stored
		try
		{
			HttpResponse response = client.execute(httpGet);
			BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuffer sb = new StringBuffer("");
			String line = "";
			String NL = System.getProperty("line.separator");
			while((line = in.readLine()) != null)
			{
				sb.append(line + NL);
			}
			in.close();
			result = sb.toString(); //Resulting content of the page
			parseHighScores(result);
		}
		catch(ClientProtocolException e)
		{
			display("ClientProtocolException");
		}
		catch(Exception e)
		{
			display("Exception");
		}
	}
	public void display(String string)
	{
		Toast.makeText(getBaseContext(), string, 300000).show();
	}
	
	@Override
	public void onBackPressed()
	{
		super.onBackPressed();
		this.finish();
	}
	public void parseHighScores(String scores)
	{
		//highScores = scores.split(" ");
		StringTokenizer st = new StringTokenizer(scores);
		int count = st.countTokens();
		highScores = new String[count];
		count = 0;
		while (st.hasMoreElements()) 
		{
			highScores[count] = "" + st.nextElement();
			count++;
		}
		
		skills = new String[26][3];
		for(int i = 0; i< 26; i++)
		{
			st = new StringTokenizer(highScores[i],",");
			int count2 = 0;
			while(st.hasMoreElements())
			{
				skills[i][count2] = "" + st.nextElement();
				if(skills[i][count2].contains("-1"))
				{
					skills[i][count2] = "0";
				}
				count2++;
			}
		}
		setViews();
	}
	
	public void setViews()
	{
		oskill.setText("Overall");
		olevel.setText(skills[OVERALL][LEVEL]);
		orank.setText(skills[OVERALL][RANK]);
		ototalxp.setText(skills[OVERALL][TOTALXP]);
		
		askill.setText("Attack");
		alevel.setText(skills[ATTACK][LEVEL]);
		arank.setText(skills[ATTACK][RANK]);
		atotalxp.setText(skills[ATTACK][TOTALXP]);
		
		dskill.setText("Defense");
		dlevel.setText(skills[DEFENSE][LEVEL]);
		drank.setText(skills[DEFENSE][RANK]);
		dtotalxp.setText(skills[DEFENSE][TOTALXP]);
		
		sskill.setText("Strength");
		slevel.setText(skills[STRENGTH][LEVEL]);
		srank.setText(skills[STRENGTH][RANK]);
		stotalxp.setText(skills[STRENGTH][TOTALXP]);
		
		cskill.setText("Hitpoints");
		clevel.setText(skills[CONSTITUTION][LEVEL]);
		crank.setText(skills[CONSTITUTION][RANK]);
		ctotalxp.setText(skills[CONSTITUTION][TOTALXP]);
		
		//display("skills[RANGED][TOTALXP]=" + skills[RANGED][TOTALXP]);
		rskill.setText("Ranged");
		rlevel.setText(skills[RANGED][LEVEL]);
		rrank.setText(skills[RANGED][RANK]);
		rtotalxp.setText(skills[RANGED][TOTALXP]);
		
		pskill.setText("Prayer");
		plevel.setText(skills[PRAYER][LEVEL]);
		prank.setText(skills[PRAYER][RANK]);
		ptotalxp.setText(skills[PRAYER][TOTALXP]);
		
		mskill.setText("Magic");
		mlevel.setText(skills[MAGIC][LEVEL]);
		mrank.setText(skills[MAGIC][RANK]);
		mtotalxp.setText(skills[MAGIC][TOTALXP]);
		
		coskill.setText("Cooking");
		colevel.setText(skills[COOKING][LEVEL]);
		corank.setText(skills[COOKING][RANK]);
		cototalxp.setText(skills[COOKING][TOTALXP]);
		
		wskill.setText("Woodcutting");
		wlevel.setText(skills[WOODCUTTING][LEVEL]);
		wrank.setText(skills[WOODCUTTING][RANK]);
		wtotalxp.setText(skills[WOODCUTTING][TOTALXP]);
		
		flskill.setText("Fletching");
		fllevel.setText(skills[FLETCHING][LEVEL]);
		flrank.setText(skills[FLETCHING][RANK]);
		fltotalxp.setText(skills[FLETCHING][TOTALXP]);
		
		fskill.setText("Fishing");
		flevel.setText(skills[FISHING][LEVEL]);
		frank.setText(skills[FISHING][RANK]);
		ftotalxp.setText(skills[FISHING][TOTALXP]);
		
		fiskill.setText("Firemaking");
		filevel.setText(skills[FIREMAKING][LEVEL]);
		firank.setText(skills[FIREMAKING][RANK]);
		fitotalxp.setText(skills[FIREMAKING][TOTALXP]);
		
		crskill.setText("Crafting");
		crlevel.setText(skills[CRAFTING][LEVEL]);
		crrank.setText(skills[CRAFTING][RANK]);
		crtotalxp.setText(skills[CRAFTING][TOTALXP]);
		
		smskill.setText("Smithing");
		smlevel.setText(skills[SMITHING][LEVEL]);
		smrank.setText(skills[SMITHING][RANK]);
		smtotalxp.setText(skills[SMITHING][TOTALXP]);
		
		miskill.setText("Mining");
		milevel.setText(skills[MINING][LEVEL]);
		mirank.setText(skills[MINING][RANK]);
		mitotalxp.setText(skills[MINING][TOTALXP]);
		
		hskill.setText("Herblore");
		hlevel.setText(skills[HERBLORE][LEVEL]);
		hrank.setText(skills[HERBLORE][RANK]);
		htotalxp.setText(skills[HERBLORE][TOTALXP]);
		
		agskill.setText("Agility");
		aglevel.setText(skills[AGILITY][LEVEL]);
		agrank.setText(skills[AGILITY][RANK]);
		agtotalxp.setText(skills[AGILITY][TOTALXP]);
		
		tskill.setText("Thieving");
		tlevel.setText(skills[THIEVING][LEVEL]);
		trank.setText(skills[THIEVING][RANK]);
		ttotalxp.setText(skills[THIEVING][TOTALXP]);
		
		slskill.setText("Slayer");
		sllevel.setText(skills[SLAYER][LEVEL]);
		slrank.setText(skills[SLAYER][RANK]);
		sltotalxp.setText(skills[SLAYER][TOTALXP]);
		
		faskill.setText("Farming");
		falevel.setText(skills[FARMING][LEVEL]);
		farank.setText(skills[FARMING][RANK]);
		fatotalxp.setText(skills[FARMING][TOTALXP]);
		
		rcskill.setText("Runecrafting");
		rclevel.setText(skills[RUNECRAFTING][LEVEL]);
		rcrank.setText(skills[RUNECRAFTING][RANK]);
		rctotalxp.setText(skills[RUNECRAFTING][TOTALXP]);
		
		huskill.setText("Hunter");
		hulevel.setText(skills[HUNTER][LEVEL]);
		hurank.setText(skills[HUNTER][RANK]);
		hutotalxp.setText(skills[HUNTER][TOTALXP]);
		
		ctskill.setText("Construction");
		ctlevel.setText(skills[CONSTRUCTION][LEVEL]);
		ctrank.setText(skills[CONSTRUCTION][RANK]);
		cttotalxp.setText(skills[CONSTRUCTION][TOTALXP]);
		
		suskill.setText("Summoning");
		sulevel.setText(skills[SUMMONING][LEVEL]);
		surank.setText(skills[SUMMONING][RANK]);
		sutotalxp.setText(skills[SUMMONING][TOTALXP]);
		
		duskill.setText("Dungeoneering");
		dulevel.setText(skills[DUNGEONEERING][LEVEL]);
		durank.setText(skills[DUNGEONEERING][RANK]);
		dutotalxp.setText(skills[DUNGEONEERING][TOTALXP]);
		
	}
}
