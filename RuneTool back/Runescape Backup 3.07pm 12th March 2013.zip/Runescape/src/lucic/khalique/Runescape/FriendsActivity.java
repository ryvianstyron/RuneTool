package lucic.khalique.Runescape;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class FriendsActivity extends ListActivity
{
	String function = "no function";
	String stringToReturn = null;
	String friendsString = null;
	SharedPreferences settings;
	SharedPreferences.Editor editor;
	ArrayList<HashMap<String,Object>> list = new ArrayList<HashMap<String, Object>>();
	
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.friends);
		
		SimpleAdapter adapter = new SimpleAdapter(this, list,
				R.layout.friendlistitem, new String[] { "friend" },
				new int[] { R.id.friend });
		//clearFriends();
		populateList();
		setListAdapter(adapter);
		
	}
	public void populateList()
	{
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		
		String friendsString = settings.getString("friends", null);
		
		if(friendsString != null)
		{
			String [] friends = friendsString.split(",");
			for (int i = 0; i < friends.length; i++)
			{
				HashMap<String, Object> temp = new HashMap<String, Object>();
				temp.put("friend", friends[i]);
				list.add(temp);
			}
		}
	}
	public boolean onCreateOptionsMenu(Menu menu)
    {
    	MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.friends_menu, menu);
        
        MenuItem modules = (MenuItem)menu.findItem(R.id.logout);
        MenuItem addFriend = (MenuItem)menu.findItem(R.id.addfriend);
        MenuItem deleteFriend = (MenuItem)menu.findItem(R.id.deletefriend);
        
        //MenuItem settings = (MenuItem)menu.findItem(R.id.settings_menu_it;
        //modules.setIntent(new Intent(this, ModuleList.class));
        //settings.setIntent(new Intent(this, Settings.class).);
        return true;
    }
	
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Create settings and editor
		settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		editor = settings.edit();
		// Create dialog 
		
		final Dialog dialog = new Dialog(FriendsActivity.this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.addordeletefrienddialog);
		dialog.setCancelable(false);
		
		final EditText friend = (EditText)dialog.findViewById(R.id.friendname);
		Button dismiss = (Button)dialog.findViewById(R.id.dismiss);
		Button addorDelete = (Button)dialog.findViewById(R.id.addordelete);
		Button addorDeleteImage = (Button)dialog.findViewById(R.id.adddeleteimage);
		TextView title = (TextView)dialog.findViewById(R.id.adddeletetitle);
		
		dismiss.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					dialog.dismiss();
				}
			});
		addorDelete.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					if(friend.getText().toString().equals(""))
					{
						Toast.makeText(FriendsActivity.this, "Please enter a name..", Toast.LENGTH_SHORT).show();
					}
					else
					{
						dialog.dismiss();
						stringToReturn = friend.getText().toString().trim();
						if(function.equals("add"))
						{
							if(stringToReturn!=null)
				     		{
					     		// Get current friends
					    		String friendsString = settings.getString("friends", null);
					    		if(friendsString == null)//no friends
					    		{
					    			friendsString = "";
					    			friendsString = friendsString.concat(stringToReturn);
					    		}
					    		else
					    		{
					    			friendsString = friendsString.concat("," + stringToReturn);
					    		}
					     		editor.putString("friends", friendsString);
					     		editor.commit();
					     		updateList();
				     		}
						}
						else if(function.equals("delete"))
						{
					        	 friendsString = settings.getString("friends", null);
					        	 String [] friends = friendsString.split(",");
					        	 ArrayList<String> friendList = new ArrayList<String>();
					        	 for(String s : friends)
					        	 {
					        		 friendList.add(s);
					        	 }
					        	 ArrayList<String> temp = friendList; // This is creating a reference
					        	 for(String s : friendList)
					        	 {
					        		if(stringToReturn.equals(s))
				        			 {
				        				 temp.remove(s);
				        				 break;
				        			 }
					        	 }
					        	 //form string again
					        	 String updatedfriends = "";
					        	 if(temp.size() > 0)
					        	 {	 
					        		 for(String s : temp)
					        		 {
					        			 updatedfriends = updatedfriends + s + ",";
					        		 }
					        		 updatedfriends = updatedfriends.substring(0, updatedfriends.length()-1);
					        	 }
					        	 else updatedfriends = null;
					        	 editor.putString("friends", updatedfriends);
					        	 editor.commit();
					        	 updateList();
						}
					}
				}
			});
		
		// handle item selection
	     switch (item.getItemId()) 
	     {
	         case R.id.logout:
	        	 
	        	 editor.clear();
	        	 editor.commit();
	        	 Intent intent = new Intent(FriendsActivity.this, RegistrationActivity.class);
	        	 startActivity(intent);
	        	 finish();
	             return true;
	             
	         case R.id.addfriend:
	        	 
	        	function = "add";
	        	addorDeleteImage.setBackgroundResource(R.drawable.addfriend);
	 			title.setText("Add Friend");
	 			addorDelete.setText("Add Friend");
	 			dialog.show();
	     		return true;
	     		
	         case R.id.deletefriend:
	        	 
	        	function = "delete"; 
	        	addorDeleteImage.setBackgroundResource(R.drawable.deletefriend);
	 			title.setText("Delete Friend");
	 			addorDelete.setText("Delete Friend");
	 			
	 			friendsString = settings.getString("friends", null);
	 			if(friendsString == null)
	 			{
	 				Toast.makeText(FriendsActivity.this, "There are no friends to delete..", Toast.LENGTH_SHORT).show();
	 			}
	 			else
	 			{
	 				dialog.show();
	 			}
	        	return true;
	        	
	         default:return super.onOptionsItemSelected(item);
	     }
	}
	
	public void clearFriends()
	{
		settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		editor = settings.edit();
		editor.putString("friends", null);
 		editor.commit();
	}
	public void updateList()
	{
		 Intent intentRestart = new Intent(FriendsActivity.this, FriendsActivity.class);
    	 startActivity(intentRestart);
    	 finish();
	}
	public void onListItemClick(ListView l, View v, int position, long id)
	{
		super.onListItemClick(l, v, position, id);
		final String friendName = l.getItemAtPosition(position).toString().substring(8, l.getItemAtPosition(position).toString().length()-1);
		final Dialog dialog = new Dialog(FriendsActivity.this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.viewfriendstuff);
		dialog.setCancelable(true);

		TextView title = (TextView) dialog.findViewById(R.id.friendtitle);
		LinearLayout al= (LinearLayout)dialog.findViewById(R.id.clickal);
		LinearLayout hs= (LinearLayout)dialog.findViewById(R.id.clickhs);
		
		title.setText(friendName);
		
		al.setOnClickListener(new OnClickListener(){
			public void onClick(View w)
			{
				try 
				{
					/** Handling XML */
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();

					/** Send URL to parse XML Tags */
					URL sourceUrl = new URL
					("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + friendName);
					/**
					 * Create handler to handle XML Tags ( extends
					 * DefaultHandler )
					 */
					//MyXMLHandler myXMLHandler = new MyXMLHandler();
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					//Log.i("EXCEPTION:","HomeActivity.java, line 121 - xml not parsed");
				}
					/** Get result from MyXMLHandler XMLlist Object */
					XMLList alogList = MyXMLHandler.xMLList;

				// Send the parsed data to the  news listview
				Intent in = new Intent(FriendsActivity.this, Alog.class);
				Bundle b = new Bundle();
			
				b.putStringArrayList("titleList", alogList.getTitle());
				b.putStringArrayList("linkList", alogList.getLink());
				b.putStringArrayList("descriptionList", alogList.getDescription());
				b.putStringArrayList("dateList",alogList.getDate());
				b.putStringArrayList("categories", alogList.getCategory());
				in.putExtras(b);
			
				startActivity(in);
				dialog.dismiss();
			}
		});
		hs.setOnClickListener(new OnClickListener(){
			public void onClick(View w)
			{
				Intent intent = new Intent(FriendsActivity.this, HighScores2.class);
				Bundle b = new Bundle();
				b.putString("username",friendName);
				intent.putExtras(b);
				startActivity(intent);
				dialog.dismiss();
			}
		});
		dialog.show();
	}
}
