package lucic.khalique.Runescape;

import java.io.FileNotFoundException;
import java.net.ConnectException;
import java.net.URL;
import java.net.UnknownHostException;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends Activity
{
	String username = "";
	Button alog;
	Button news;
	Button forumTime;
	Button hiScores;
	Button ge;
	Button friends;
	EditText usernameEntry;
	SharedPreferences preferences;
	ImageView image;
	TextView usernametv;
	Dialog dialog;
	private XMLList newsList;
	private XMLList alogList;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		
		friends = (Button)findViewById(R.id.friendButton);
		forumTime = (Button)findViewById(R.id.timeButton);
		news = (Button) findViewById(R.id.newsButton);
		alog = (Button) findViewById(R.id.alogButton);
		hiScores = (Button)findViewById(R.id.hiScoresButton);
		ge = (Button)findViewById(R.id.geButton);
		
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		
		String memberType = settings.getString("memberType",null);
		String memberName = settings.getString("memberName",null);		
	
		if(memberType.equals("free2play"))
		{
			alog.setVisibility(View.GONE);
			hiScores.setVisibility(View.GONE);
		}
		else if(memberType.equals("pay2play"))
		{
			username = memberName;
		}
		friends.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, FriendsActivity.class);
				startActivity(intent);
			}
		});
		hiScores.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
					Intent intent = new Intent(HomeActivity.this, HighScores2.class);
					Bundle b = new Bundle();
					b.putString("username",username);
					intent.putExtras(b);
					startActivity(intent);
			}
		});
		ge.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, GeHome.class);
				startActivity(intent);
			}
		});
		alog.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Utility.callLoaderAndHandler(new AlogLoader());
			}
		});
		news.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Utility.callLoaderAndHandler(new NewsLoader());
			}
		});
		forumTime.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent(HomeActivity.this, Time.class);
				startActivity(intent);
			}
		});
	}
	public void onResume()
	{
		super.onResume();
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		String registered = settings.getString("registered","null");
		if(registered != null && registered.equals("no"))
		{
			finish();
		}
	}
	public boolean onCreateOptionsMenu(Menu menu)
    {
    	MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.homemenu, menu);
        return true;
    }
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId()) 
		{
			case R.id.logout:
				SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
				SharedPreferences.Editor editor;
				editor = settings.edit();
				editor.clear();
				editor.putString("registered", "no");
				editor.commit();
				Intent intent = new Intent(HomeActivity.this,RegistrationActivity.class);
				startActivity(intent);
				finish();
				return true;
			case R.id.info:
				intent = new Intent(HomeActivity.this, Info.class);
				startActivity(intent);
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	private class AlogLoader extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = Utility.createLoadingScreen("Loading Adventurers Log.. ", HomeActivity.this, dialog);
			dialog.show();
		}
		protected String doInBackground(String... params)
		{
			while(!isCancelled())
			{
				try 
				{
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					username = username.replace(" ", "+");
					URL sourceUrl = new URL("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + username);
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
					alogList = MyXMLHandler.xMLList;
					return "completed";
				} 
				catch(ConnectException ce)
				{
					ce.printStackTrace();
					return "ConnectException";
				}
				catch(UnknownHostException unh)
				{
					unh.printStackTrace();
					return "UnknownHostException";
				}
				catch(FileNotFoundException fnf)
				{
					fnf.printStackTrace();
					return "FileNotFoundException";
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					return "incomplete: " + e.toString();
				}
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				Intent in = new Intent(HomeActivity.this, Alog.class);
				Bundle b = new Bundle();
				b.putStringArrayList("titleList", alogList.getTitle());
				b.putStringArrayList("linkList", alogList.getLink());
				b.putStringArrayList("descriptionList", alogList.getDescription());
				b.putStringArrayList("dateList",alogList.getDate());
				b.putStringArrayList("categories", alogList.getCategory());
				in.putExtras(b);
				startActivity(in);
				dialog.dismiss();
				dialog = null;
			}
			else if(result.equals("UnknownHostException") || result.equals("ConnectException"))
			{
				dialog.dismiss();
				Toast.makeText(HomeActivity.this, "Please double check your internet connection ..", Toast.LENGTH_LONG).show();
			}
			else if(result.equals("FileNotFoundException"))
			{
				dialog.dismiss();
				Toast.makeText(HomeActivity.this, "Your Adventurer's Log cannot be found.\nAre you a member?", Toast.LENGTH_LONG).show();
				
			}
			else if(result.contains("incomplete"))
			{
				dialog.dismiss();
				Toast.makeText(HomeActivity.this, "Adventurer's Log is unavailable, please try again later ..",Toast.LENGTH_LONG).show();
				if(Utility.neverBug(HomeActivity.this) == false)
				{
					Utility.sendBugReport(HomeActivity.this, "HomeActivity", "AlogLoader AsyncTask doInBackground()", result);
				}
			}
		}
		@Override
		protected void onCancelled()
		{
			dialog.dismiss();
			Toast.makeText(HomeActivity.this, "Adventurer's Log response from www.runescape.com is slow, please try again later ..",Toast.LENGTH_LONG).show();
		}
	}
	private class NewsLoader extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = Utility.createLoadingScreen("Loading News ..", HomeActivity.this, dialog);
			dialog.show();
		}
		@Override
		protected String doInBackground(String... params)
		{
			while(!isCancelled())
			{
				try 
				{
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					URL sourceUrl = new URL("http://services.runescape.com/m=news/latest_news.rss"); ;
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
					newsList = MyXMLHandler.xMLList;
					return "completed";
				} 
				catch(ConnectException ce)
				{
					ce.printStackTrace();
					return "ConnectException";
				}
				catch(UnknownHostException unh)
				{
					unh.printStackTrace();
					return "UnknownHostException";
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					return "incomplete: " + e.toString();
				}
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				Intent in = new Intent(HomeActivity.this, News.class);
				Bundle b = new Bundle();
				b.putStringArrayList("titleList", newsList.getTitle());
				b.putStringArrayList("linkList", newsList.getLink());
				b.putStringArrayList("descriptionList", newsList.getDescription());
				b.putStringArrayList("dateList",newsList.getDate());
				b.putStringArrayList("categories", newsList.getCategory());
				in.putExtras(b);
				dialog.dismiss();
				startActivity(in);
			}
			else if(result.equals("UnknownHostException") || result.equals("ConnectException"))
			{
				dialog.dismiss();
				Toast.makeText(HomeActivity.this, "Please double check your internet connection ..", Toast.LENGTH_LONG).show();
			}
			else if(result.contains("incomplete"))
			{
				dialog.dismiss();
				Toast.makeText(HomeActivity.this, "Unable to load News at this time, please try again later ..",Toast.LENGTH_LONG).show();
				if(Utility.neverBug(HomeActivity.this) == false)
				{
					Utility.sendBugReport(HomeActivity.this, "HomeActivity", "NewsLoader AsyncTask doInBackground()", result);
				}
			}
		}
		@Override
		protected void onCancelled()
		{
			dialog.dismiss();
			Toast.makeText(HomeActivity.this, "News response from www.runescape.com is slow, please try again later ..",Toast.LENGTH_LONG).show();
		}
	}
}