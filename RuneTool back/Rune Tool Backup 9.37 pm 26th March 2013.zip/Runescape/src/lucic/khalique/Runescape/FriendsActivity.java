package lucic.khalique.Runescape;

import java.io.FileNotFoundException;
import java.net.ConnectException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class FriendsActivity extends ListActivity
{
	String function = "no function";
	String stringToReturn = null;
	String friendsString = null;
	SharedPreferences settings;
	SharedPreferences.Editor editor;
	ArrayList<HashMap<String,Object>> list = new ArrayList<HashMap<String, Object>>();
	Dialog dialog;
	String friendName = "";
	XMLList alogList;
	Dialog friendInfo;
	boolean friendValidated = false;
	AlogLoader loader;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.friends);
		
		SimpleAdapter adapter = new SimpleAdapter(this, list,
				R.layout.friendlistitem, new String[] { "friend" },
				new int[] { R.id.friend });
		populateList();
		setListAdapter(adapter);
	}
	public void onResume()
	{
		super.onResume();
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		String registered = settings.getString("registered","null");
		if(registered != null && registered.equals("no"))
		{
			finish();
		}
	}
	public void populateList()
	{
		SharedPreferences settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		
		String friendsString = settings.getString("friends", null);
		
		if(friendsString != null)
		{
			String [] friends = friendsString.split(",");
			for (int i = 0; i < friends.length; i++)
			{
				HashMap<String, Object> temp = new HashMap<String, Object>();
				temp.put("friend", friends[i]);
				list.add(temp);
			}
		}
	}
	public void onListItemClick(ListView l, View v, int position, long id)
	{
		super.onListItemClick(l, v, position, id);
		friendName = l.getItemAtPosition(position).toString().substring(8, l.getItemAtPosition(position).toString().length()-1);
		friendInfo = new Dialog(FriendsActivity.this);
		friendInfo.requestWindowFeature(Window.FEATURE_NO_TITLE);
		friendInfo.setContentView(R.layout.viewfriendstuff);
		friendInfo.setCancelable(true);
		TextView title = (TextView) friendInfo.findViewById(R.id.friendtitle);
		LinearLayout al= (LinearLayout)friendInfo.findViewById(R.id.clickal);
		LinearLayout hs= (LinearLayout)friendInfo.findViewById(R.id.clickhs);
		title.setText(friendName);
		al.setOnClickListener(new OnClickListener()
		{
			public void onClick(View w)
			{
				Utility.callLoaderAndHandler(new AlogLoader());
			}
		});
		hs.setOnClickListener(new OnClickListener()
		{
			public void onClick(View w)
			{
				Intent intent = new Intent(FriendsActivity.this, HighScores2.class);
				Bundle b = new Bundle();
				b.putString("username",friendName);
				b.putString("userType", "friend");
				intent.putExtras(b);
				startActivity(intent);
				friendInfo.dismiss();
			}
		});
		friendInfo.show();
	}
	private class Validator extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = Utility.createLoadingScreen("Validating " + stringToReturn + " ..", FriendsActivity.this, dialog);
			dialog.show();
		}
		protected String doInBackground(String... params)
		{
			while(!isCancelled())
			{
				try 
				{
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					friendName = friendName.replace(" ","+");
					URL sourceUrl = new URL("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + friendName);
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
					alogList = MyXMLHandler.xMLList;
					return "completed";
				}
				catch(ConnectException ce)
				{
					ce.printStackTrace();
					return "ConnectException";
				}
				catch(FileNotFoundException fnf)
				{
					fnf.printStackTrace();
					return "FileNotFoundException";
				}
				catch(UnknownHostException unh)
				{
					unh.printStackTrace();
					return "UnknownHostException";
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					return "incomplete: " + e.toString();
				}
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				dialog.dismiss();
				String friendsString = settings.getString("friends", null);
	    		if(friendsString == null)//no friends
	    		{
	    			friendsString = "";
	    			friendsString = friendsString.concat(stringToReturn);
	    		}
	    		else
	    		{
	    			friendsString = friendsString.concat("," + stringToReturn);
	    		}
	     		editor.putString("friends", friendsString);
	     		editor.commit();
	     		updateList();
			}
			else if(result.equals("FileNotFoundException"))
			{
				dialog.dismiss();
				Toast.makeText(FriendsActivity.this, "Friend Validation failed.\nIs the username spelt correctly?\nIs your friend a member?", Toast.LENGTH_LONG).show();
			}
			else if(result.equals("UnknownHostException") || result.equals("ConnectException"))
			{
				dialog.dismiss();
				Toast.makeText(FriendsActivity.this, "Please double check your internet connection ..", Toast.LENGTH_LONG).show();
			}
			else if(result.contains("incomplete"))
			{
				dialog.dismiss();
				Toast.makeText(FriendsActivity.this, "Unable to validate friend at this time, please try again later ..", Toast.LENGTH_LONG).show();
				if(Utility.neverBug(FriendsActivity.this) == false)
				{
					Utility.sendBugReport(FriendsActivity.this, "FriendsActivity", "Validator AsyncTask doInBackground()", result);
				}
			}
		}
		@Override
		protected void onCancelled()
		{
			Toast.makeText(FriendsActivity.this,"Validation response from www.runescape.com is slow, please try again later ..", Toast.LENGTH_LONG).show();
			dialog.dismiss();
		}
	}
	private class AlogLoader extends AsyncTask<String, Void, String>
	{
		protected void onPreExecute()
		{
			dialog = Utility.createLoadingScreen("Loading " + friendName + " Adventurer's Log..", FriendsActivity.this, dialog);
			dialog.show();
			friendInfo.dismiss();
		}
		protected String doInBackground(String... params)
		{	
			while(!isCancelled())
			{
				try 
				{
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					friendName = friendName.replace(" ","+");
					URL sourceUrl = new URL("http://services.runescape.com/m=adventurers-log/rssfeed?searchName=" + friendName);
					xr.setContentHandler(new MyXMLHandler());
					xr.parse(new InputSource(sourceUrl.openStream()));
					alogList = MyXMLHandler.xMLList;
					return "completed";
				}
				catch(ConnectException ce)
				{
					ce.printStackTrace();
					return "ConnectException";
				}
				catch(FileNotFoundException fnf)
				{
					fnf.printStackTrace();
					return "FileNotFoundException";
				}
				catch(UnknownHostException unh)
				{
					unh.printStackTrace();
					return "UnknownHostException";
				}
				catch (Exception e) 
				{
					e.printStackTrace();
					return "incomplete" + e.toString();
				}
			}
			return "cancelled";
		}
		protected void onPostExecute(String result)
		{
			if(result.equals("completed") && dialog.isShowing())
			{
				Intent in = new Intent(FriendsActivity.this, Alog.class);
				Bundle b = new Bundle();
				b.putStringArrayList("titleList", alogList.getTitle());
				b.putStringArrayList("linkList", alogList.getLink());
				b.putStringArrayList("descriptionList", alogList.getDescription());
				b.putStringArrayList("dateList",alogList.getDate());
				b.putStringArrayList("categories", alogList.getCategory());
				in.putExtras(b);
				startActivity(in);
				dialog.dismiss();
			}
			else if(result.contains("FileNotFoundException"))
			{
				dialog.dismiss();
				Toast.makeText(FriendsActivity.this, "Friend's Adventurer's Log is not found.\nIs your friend still a member?", Toast.LENGTH_LONG).show();
			}
			else if(result.equals("UnknownHostException") || result.equals("ConnectException"))
			{
				dialog.dismiss();
				Toast.makeText(FriendsActivity.this, "Please double check your internet connection ..", Toast.LENGTH_LONG).show();
			}
			else if(result.contains("incomplete"))
			{
				Toast.makeText(FriendsActivity.this, "Unable to load friend's Adventurer's Log at this time. Please try again later ..", Toast.LENGTH_LONG).show();
				dialog.dismiss();
				if(Utility.neverBug(FriendsActivity.this) == false)
				{
					Utility.sendBugReport(FriendsActivity.this, "FriendsActivity", "AlogLoader AsyncTask doInBackground()", result);
				}
			}
		}
		@Override
		protected void onCancelled()
		{
			Toast.makeText(FriendsActivity.this,"Response from www.runescape.com is slow, please try again later ..", Toast.LENGTH_LONG).show();
			dialog.dismiss();
		}
	}
	public boolean onCreateOptionsMenu(Menu menu)
    {
    	MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.friends_menu, menu);
        return true;
    }
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		// Create settings and editor
		settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		editor = settings.edit();
		// Create dialog 
		
		final Dialog dialog = new Dialog(FriendsActivity.this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.addordeletefrienddialog);
		dialog.setCancelable(false);
		
		final EditText friend = (EditText)dialog.findViewById(R.id.friendname);
		Button dismiss = (Button)dialog.findViewById(R.id.dismiss);
		Button addorDelete = (Button)dialog.findViewById(R.id.addordelete);
		Button addorDeleteImage = (Button)dialog.findViewById(R.id.adddeleteimage);
		TextView title = (TextView)dialog.findViewById(R.id.adddeletetitle);
		
		dismiss.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				dialog.dismiss();
			}
		});
		addorDelete.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if(friend.getText().toString().equals(""))
				{
					Toast.makeText(FriendsActivity.this, "Please enter a username..", Toast.LENGTH_LONG).show();
				}
				else
				{
					dialog.dismiss();
					stringToReturn = friend.getText().toString().trim();
					if(function.equals("add")) // validate friend being added
					{
						if(stringToReturn!=null)
			     		{
							if(matchesCurrentUser(stringToReturn))
							{
								Toast.makeText(FriendsActivity.this,"Your username cannot be added to your friendslist .. add a friend instead :)", Toast.LENGTH_LONG).show();
							}
							else if(!matchesCurrentUser(stringToReturn))
							{
								// check for duplicates
								String friendString = settings.getString("friends",null);
								boolean duplicateExists = duplicate(stringToReturn, friendString);
								if(!duplicateExists)
								{
									// validate friend being added
									friendName = stringToReturn; 
									Utility.callLoaderAndHandler(new Validator());
								}
								else if(duplicateExists == true)
								{
									Toast.makeText(FriendsActivity.this,"Friend name already exists..", Toast.LENGTH_LONG).show();
								}
							}
			     		}
					}
					else if(function.equals("delete"))
					{
				        	 friendsString = settings.getString("friends", null);
				        	 String [] friends = friendsString.split(",");
				        	 ArrayList<String> friendList = new ArrayList<String>();
				        	 for(String s : friends)
				        	 {
				        		 friendList.add(s);
				        	 }
				        	 ArrayList<String> temp = friendList; // This is creating a reference
				        	 for(String s : friendList)
				        	 {
				        		if(stringToReturn.equals(s))
			        			 {
			        				 temp.remove(s);
			        				 break;
			        			 }
				        	 }
				        	 //form string again
				        	 String updatedfriends = "";
				        	 if(temp.size() > 0)
				        	 {	 
				        		 for(String s : temp)
				        		 {
				        			 updatedfriends = updatedfriends + s + ",";
				        		 }
				        		 updatedfriends = updatedfriends.substring(0, updatedfriends.length()-1);
				        	 }
				        	 else updatedfriends = null;
				        	 editor.putString("friends", updatedfriends);
				        	 editor.commit();
				        	 updateList();
					}
				}
			}
		});
	     switch (item.getItemId()) 
	     {
	         case R.id.logout:
	        	 editor.clear();
	        	 editor.putString("registered","no");
	        	 editor.commit();
	        	 Intent intent = new Intent(FriendsActivity.this, RegistrationActivity.class);
	        	 startActivity(intent);
	        	 finish();
	             return true;
	         case R.id.addfriend:
	        	function = "add";
	        	addorDeleteImage.setBackgroundResource(R.drawable.addfriend);
	 			title.setText("Add Friend");
	 			addorDelete.setText("Add Friend");
	 			dialog.show();
	     		return true;
	         case R.id.deletefriend:
	        	function = "delete"; 
	        	addorDeleteImage.setBackgroundResource(R.drawable.deletefriend);
	 			title.setText("Delete Friend");
	 			addorDelete.setText("Delete Friend");
	 			friendsString = settings.getString("friends", null);
	 			if(friendsString == null)
	 			{
	 				Toast.makeText(FriendsActivity.this, "There are no friends to delete..", Toast.LENGTH_SHORT).show();
	 			}
	 			else
	 			{
	 				dialog.show();
	 			}
	        	return true;
	         default:return super.onOptionsItemSelected(item);
	     }
	}
	public boolean matchesCurrentUser(String friendToAdd)
	{
		boolean result = false;
		settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		editor = settings.edit();
		
		String currentUser = settings.getString("memberName", null);
		
		if(currentUser.equals(friendToAdd))
		{
			result = true;
		}
		else if(!currentUser.equals(friendToAdd))
		{
			result = false;
		}
		return result;
	}
	public boolean duplicate(String friendToAdd, String friendlist)
	{
		boolean duplicate = false;
		if(friendlist == null)
		{
			return false;
		}
		else
		{
			String [] friendArray = friendlist.split(",");
			for(String s : friendArray)
			{
				if(s.equals(friendToAdd))
				{
					duplicate = true;
					break;
				}
			}
			return duplicate;
		}
	}
	public void clearFriends()
	{
		settings = getSharedPreferences("SETTINGS",MODE_PRIVATE);
		editor = settings.edit();
		editor.putString("friends", null);
 		editor.commit();
	}
	public void updateList()
	{
		 Intent intentRestart = new Intent(FriendsActivity.this, FriendsActivity.class);
    	 startActivity(intentRestart);
    	 finish();
	}
}
